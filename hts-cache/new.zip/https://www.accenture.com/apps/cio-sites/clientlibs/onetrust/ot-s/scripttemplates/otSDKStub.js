
<!DOCTYPE HTML>
<html lang="en-US">
    <head>
    <meta charset="UTF-8"/>
    
    
        <title>Page Not Found</title>
    
    
    
    <meta name="template" content="generic-template"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    

    
        
    
    
    

	
    
<script src="/etc.clientlibs/clientlibs/granite/jquery.lc-7842899024219bcbdb5e72c946870b79-lc.min.js"></script>
<script src="/etc.clientlibs/clientlibs/granite/utils.lc-e7bf340a353e643d198b25d0c8ccce47-lc.min.js"></script>
<script src="/etc.clientlibs/clientlibs/granite/jquery/granite.lc-543d214c88dfa6f4a3233b630c82d875-lc.min.js"></script>
<script src="/etc.clientlibs/foundation/clientlibs/jquery.lc-dd9b395c741ce2784096e26619e14910-lc.min.js"></script>





	
	<link rel="preconnect" href="//cdnssl.clicktale.net/" crossorigin/>
	<link rel="preconnect" href="//cdn.cookielaw.org/" crossorigin/>
	<link rel="preconnect" href="//assets.adobedtm.com/" crossorigin/>
	<link rel="preconnect" href="//api.company-target.com/" crossorigin/>
	<link rel="preconnect" href="//dpm.demdex.net/" crossorigin/>
	<link rel="preconnect" href="//play.vidyard.com/" crossorigin/>
	<link rel="preconnect" href="//somni.accenture.com/" crossorigin/>
	<link rel="preconnect" href="//accenture.demdex.net/" crossorigin/>
	<link rel="preconnect" href="//ml314.com/" crossorigin/>
	<link rel="preconnect" href="//cm.everesttech.net/" crossorigin/>
	<link rel="preconnect" href="//target.accenture.com/" crossorigin/>
	<link rel="preconnect" href="//cdnjs.cloudflare.com/" crossorigin/>
	<link rel="preconnect" href="//idsync.rlcdn.com/" crossorigin/>

	<link rel="dns-prefetch" href="//cdn.cookielaw.org/"/>
	<link rel="dns-prefetch" href="//assets.adobedtm.com/"/>
	<link rel="dns-prefetch" href="//api.company-target.com/"/>
	<link rel="dns-prefetch" href="//dpm.demdex.net/"/>
	<link rel="dns-prefetch" href="//play.vidyard.com/"/>
	<link rel="dns-prefetch" href="//somni.accenture.com/"/>
	<link rel="dns-prefetch" href="//accenture.demdex.net/"/>
	<link rel="dns-prefetch" href="//ml314.com/"/>
	<link rel="dns-prefetch" href="//cm.everesttech.net/"/>
	<link rel="dns-prefetch" href="//target.accenture.com/"/>
	<link rel="dns-prefetch" href="//cdnjs.cloudflare.com/"/>
	<link rel="dns-prefetch" href="//idsync.rlcdn.com/"/>
	<link rel="dns-prefetch" href="//cdnssl.clicktale.net/"/>



	

	

	

	

	
	
		<link rel="preload" as="font" type="font/woff2" crossorigin href="/etc.clientlibs/cio-sites/clientlibs/clientlib-site/resources/fonts/graphik-regular-web.woff2"/>
<link rel="preload" as="font" type="font/woff2" crossorigin href="/etc.clientlibs/cio-sites/clientlibs/clientlib-site/resources/fonts/graphik-semibold-web.woff2"/>
<link rel="preload" as="font" type="font/woff2" crossorigin href="/etc.clientlibs/cio-sites/clientlibs/clientlib-site/resources/fonts/graphik-black-web.woff2"/>
<link rel="preload" as="font" type="font/woff2" crossorigin href="/etc.clientlibs/cio-sites/clientlibs/clientlib-site/resources/fonts/graphik-bold-web.woff2"/>

	
	
	
	<link rel="preload" as="font" type="font/woff2" crossorigin href="/etc.clientlibs/cio-sites/clientlibs/clientlib-site/resources/fonts/reenie-beanie-regular.woff2"/>
	


<script>
	window.adobeDataLayer = window.adobeDataLayer || [];
</script>






	
	
		<script>
			adobeDataLayer.push({
				page: JSON.parse("{\x22pageData\x22:{\x22pageTagging\x22:{\x22careers\x22:{\x22careerLevel\x22:\x22\x22,\x22skill1\x22:\x22\x22,\x22skill2\x22:\x22\x22,\x22pageCategory\x22:\x22\x22},\x22blogs\x22:{\x22blogTopic\x22:\x22\x22,\x22blogName\x22:\x22\x22},\x22theme\x22:\x22\x22,\x22growthPriority\x22:\x22n\/a\x22,\x22contentFormat\x22:\x22n\/a\x22,\x22contentType\x22:\x22n\/a\x22,\x22primaryBuyerFunction\x22:\x22\x22,\x22industry\x22:\x22\x22,\x22entityL1\x22:\x22\x22,\x22entityL2\x22:\x22\x22,\x22entityL3\x22:\x22\x22,\x22entityL4\x22:\x22\x22},\x22authorInfo\x22:{\x22author\x22:\x22\x22},\x22target\x22:{\x22blockDynamicContent\x22:false},\x22pageProperties\x22:{\x22contentDate\x22:\x22\x22,\x22siteId\x22:\x22acn\x22,\x22templateName\x22:\x22atp:page not found\x22,\x22publishDate\x22:\x222023\u002D02\u002D07T03:30:01.761Z\x22,\x22guid\x22:\x22ef4435cae0e16f3befbe2667a821f550\x22,\x22pageName\x22:\x22acn:errors:404\x22,\x22countryLanguage\x22:\x22us\u002Den\x22,\x22siteBranch\x22:\x22errors\x22,\x22subFolder\x22:\x22\x22,\x22tertiaryFolder\x22:\x22\x22},\x22analytics\u002Dmodule\u002Dname\x22:\x22generic\u002D2\x22,\x22@type\x22:\x22cio\u002Dsites\/components\/page\u002Dcomponents\/generic\x22}}"),
				event: 'cmp:dataLayerLoaded',
				eventInfo: {
					path: 'page.page\u002Da9d8d0511f'
				}
			});
			adobeDataLayer.push({
         		event : 'dataLayerReady',
         		visitor : {
         			visitorInfo : {
         				visitorLoginStatus : 'anon',
         				visitorType : '',
         				visitorEmpRef : '',
         				visitorGuid : '',
         				visitorAcnEmp : '',
         				visitorAccess : '',
         				visitorCity : '',
         				visitorCountry : '',
         				visitorStateOrProvince : '',
         				visitorCarLevel : '',
         				visitorCarActivity : ''
         			},
         			visitorPreference : {
         				preferenceCity : '',
         				preferenceCountry : '',
         				preferenceIndustry : '',
         				preferenceSkill : '',
         				preferenceSpecialization : '',
         				preferenceTravelFrequency : ''
         			},
         			visitorSubscription : {
                        careersBlogSubscriber : 'false',
                        jobAlertsSubscriber : 'false',
                        lifeatAccentureSubscriber : 'false',
                        talentConnectionSubscriber : 'false'
                    }
				}
           });
		</script>
	

	

	

	

	
	
		<script>
			(function (g, b, d, f) {
				(function (a, c, d) {
					if (a) {
						var e = b.createElement("style");
						e.id = c;
						e.innerHTML = d;
						a.appendChild(e)
					}
				})(b.getElementsByTagName("head")[0], "at-body-style", d);
				setTimeout(function () {
					var a = b.getElementsByTagName("head")[0];
					if (a) {
						var c = b.getElementById("at-body-style");
						c && a.removeChild(c)
					}
				}, f)
			})(window, document, "#main {opacity: 0 !important}", 3E3);
		</script>
	

	
	<script>
		var origin = window.location.origin.toLowerCase();
		var otScript = document.createElement("script");
	    otScript.setAttribute("type", "text/javascript");
	    otScript.setAttribute("data-document-language", "true");
	    otScript.setAttribute("charset", "UTF-8");

	    if (origin.indexOf(".cdnsvc") > 1) {
	    otScript.setAttribute("src", "/etc/clientlibs/onetrust/ot-s/scripttemplates/otSDKStub.js");
	    otScript.setAttribute("data-domain-script","447538ad-b6bf-4dce-a2c6-6517ede21fc1-test");
	    }

		else if (origin.indexOf(".cn") > 1) {
	    otScript.setAttribute("src", "/etc/clientlibs/onetrust/ot-p/scripttemplates/otSDKStub.js");
		otScript.setAttribute("data-domain-script","447538ad-b6bf-4dce-a2c6-6517ede21fc1");
		}

		else {
		otScript.setAttribute("src", "https://cdn.cookielaw.org/scripttemplates/otSDKStub.js");
		otScript.setAttribute("data-domain-script","d6e38d3c-2419-4258-8e8d-d1a7d3972604");

	    }
	    document.head.appendChild(otScript);
	</script>
	

	
	<script type="text/javascript"> function OptanonWrapper() { } </script>
	<script>
		var origin = window.location.origin.toLowerCase();
		if (origin.indexOf(".cn") > 1 || origin.indexOf(".cdnsvc") > 1) {
			window.otUserLocation = 'CN';
		}else{
			
			var geolink = "//geolocation.onetrust.com/"
			var link1 = document.createElement("link");
			link1.setAttribute("rel", "preconnect");
			link1.setAttribute("href", geolink);
			link1.setAttribute("crossorigin", "");
			document.head.appendChild(link1);

			var link2 = document.createElement("link");
			link2.setAttribute("rel", "dns-prefetch");
			link2.setAttribute("href", geolink);
			document.head.appendChild(link2);

			var geolink2 = "https://geolocation.onetrust.com/cookieconsentpub/v1/geo/location"
			var link4 = document.createElement("script");
			link4.setAttribute("href", geolink2);
			document.head.appendChild(link4);


			fetch(geolink2, {
			headers: {
				'Accept': 'application/json'
			}})
			.then(response => response.json())
			.then(geo => 
				jsonFeed(geo)
			)
			
			function jsonFeed(locationJson) {
				window.otUserLocation = locationJson.country;
			}
		}
	</script>
	
	
	
	

	
	
		<meta name="title" content="Page Not Found"/>
		<meta name="description" content="404"/>
		
		
		<meta itemprop="name" content="Page Not Found"/>
		<meta itemprop="description" content="404"/>
		
	
	
	<meta name="sniply-options" content="block"/>


			<meta name="robots" content="nofollow,noindex"/>



	<link rel="canonical" href="https://www.accenture.com/us-en/errors/404"/>
	<meta property="fb:app_id" content="1391700191159700"/>
	<meta property="og:title" content="Page Not Found"/>
	
		<meta property="og:description" content="404"/>
	
	

	<meta name="twitter:card" content="summary"/>
	<meta name="twitter:title" content="Page Not Found"/>
	
		<meta name="twitter:description" content="404"/>
	
	
	
	
    



	
    
<link rel="stylesheet" href="/etc.clientlibs/cio-sites/clientlibs/clientlib-base.lc-99e6138fc3579fe6a02605a8fc47cd6b-lc.min.css" type="text/css">






	
		
    
<link rel="stylesheet" href="/etc.clientlibs/cio-sites/clientlibs/clientlib-site-above-the-fold.lc-7f5d95791329df4749c9c3f6804d87d0-lc.min.css" type="text/css">



		
    
<link rel="stylesheet" href="/etc.clientlibs/cio-sites/clientlibs/clientlib-site.lc-738554c5b6785afff863e62d949618e4-lc.min.css" type="text/css">



	
	
	





    
    
    

    

    



    


        <script type="text/javascript" src="https://assets.adobedtm.com/55621ea95d50/6d54160615c5/launch-a221892d65bb.min.js" async></script>


    
    
    
    

    
    
    


    

    

    

    

    
</head>
    <body class="generic page basicpage" id="page-a9d8d0511f" data-cmp-link-accessibility-enabled data-cmp-link-accessibility-text="opens in a new tab" data-cmp-data-layer-enabled>
        <script>
          window.adobeDataLayer = window.adobeDataLayer || [];
          adobeDataLayer.push({
              page: JSON.parse("{\x22pageData\x22:{\x22pageTagging\x22:{\x22careers\x22:{\x22careerLevel\x22:\x22\x22,\x22skill1\x22:\x22\x22,\x22skill2\x22:\x22\x22,\x22pageCategory\x22:\x22\x22},\x22blogs\x22:{\x22blogTopic\x22:\x22\x22,\x22blogName\x22:\x22\x22},\x22theme\x22:\x22\x22,\x22growthPriority\x22:\x22n\/a\x22,\x22contentFormat\x22:\x22n\/a\x22,\x22contentType\x22:\x22n\/a\x22,\x22primaryBuyerFunction\x22:\x22\x22,\x22industry\x22:\x22\x22,\x22entityL1\x22:\x22\x22,\x22entityL2\x22:\x22\x22,\x22entityL3\x22:\x22\x22,\x22entityL4\x22:\x22\x22},\x22authorInfo\x22:{\x22author\x22:\x22\x22},\x22target\x22:{\x22blockDynamicContent\x22:false},\x22pageProperties\x22:{\x22contentDate\x22:\x22\x22,\x22siteId\x22:\x22acn\x22,\x22templateName\x22:\x22atp:page not found\x22,\x22publishDate\x22:\x222023\u002D02\u002D07T03:30:01.761Z\x22,\x22guid\x22:\x22ef4435cae0e16f3befbe2667a821f550\x22,\x22pageName\x22:\x22acn:errors:404\x22,\x22countryLanguage\x22:\x22us\u002Den\x22,\x22siteBranch\x22:\x22errors\x22,\x22subFolder\x22:\x22\x22,\x22tertiaryFolder\x22:\x22\x22},\x22analytics\u002Dmodule\u002Dname\x22:\x22generic\u002D3\x22,\x22@type\x22:\x22cio\u002Dsites\/components\/page\u002Dcomponents\/generic\x22}}"),
              event:'cmp:show',
              eventInfo: {
                  path: 'page.page\u002Da9d8d0511f'
              }
          });
        </script>
        
        
            
  

<div role="region" aria-label="skip navigation">
	<a href="#main" class="cmp-skip-link">Skip to main content</a>
	<a href="#footer" class="cmp-skip-link">Skip to footer</a>
</div>


            
  

  <div class="root container responsivegrid">

    
    
    
    <div id="container-7f48ddee19" class="cmp-container">
        
        <header class="experiencefragment full-width">
<div id="header" class="cmp-experiencefragment cmp-experiencefragment--global-header">


    
    
    
    <div id="container-9985a2fe10" class="cmp-container">
        
        <div class="globalheader has-tooltip"><!-- Global Header -->

    
<div class="cmp-global-header" data-cmp-data-layer="{&#34;globalheader-a18a059eb0&#34;:{&#34;@type&#34;:&#34;cio-sites/components/blocks/b.001/globalheader&#34;,&#34;analytics-module-name&#34;:&#34;global header&#34;,&#34;analytics-template-zone&#34;:&#34;global header&#34;}}" id="globalheader-a18a059eb0">
  <nav aria-label="global">
    <div class="cmp-global-header__navbar-container">
      <div class="cmp-global-header__primary-nav">
        <div class="cmp-global-header__menu">
          <button class="cmp-global-header__menu-button" type="button" aria-expanded="false" aria-label="menu" data-cmp-data-layer="{&#34;hamburger&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/errors/404&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;menu&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
            <div>
              <span></span>
              <span></span>
              <span></span>
            </div>
          </button>
        </div>

        
	        <div class="cmp-global-header__logo" data-cmp-data-layer="{&#34;globalheader-logo-1f686d896b&#34;:{&#34;xdm:linkURL&#34;:&#34;https://www.accenture.com/us-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;logo&#34;,&#34;analytics-link-name&#34;:&#34;accenture logo - header&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
	          <a href="https://www.accenture.com/us-en" tabindex="0" data-cmp-clickable>
	            <img src="/content/dam/accenture/final/images/icons/symbol/Acc_Logo_Black_Purple_RGB.png" alt="Accenture home"/>
	          </a>
	        </div>
        
        
        

        <div class="cmp-global-header__content" role="toolbar">
			<ul class="cmp-global-header__nav-menu">
              <li class="cmp-global-header__nav-menu-item" id="globalheader-primarynavlinks-item0-a0240b3b24" data-cmp-data-layer="{&#34;globalheader-primarynavlinks-item0-a0240b3b24&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/errors/404&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;Insights&#34;,&#34;analytics-module-name&#34;:&#34;primary nav&#34;}}">
              <button class="cmp-global-header__nav-menu-label-button" type="button" aria-expanded="false" aria-haspopup="true" aria-label="Insights">Insights</button>
              <div class="cmp-global-header__nav-menu-item-content">
                    <div class="xfpage page basicpage">


    
    <div id="container-ac98b0a1f8" class="cmp-container">
        


<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
    
    <div class="navcontainer container responsivegrid aem-GridColumn aem-GridColumn--default--12"><!-- Begin Nav Container -->
<div class="cmp-global-header__drawer">
   <div class="cmp-global-header__drawer-content">
      <div class="cmp-global-header__drawer-two-columns">
	  <!-- Begin Two Container -->
         <div class="cmp-global-header__drawer-left-column">
            
               <div class="responsivegrid">


<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
    
    <div class="teaser cmp-header-featured-content aem-GridColumn aem-GridColumn--default--12">
<div id="navteaser-46978c3ab1" class="cmp-teaser" data-cmp-data-layer="{&#34;navteaser-46978c3ab1&#34;:{&#34;@type&#34;:&#34;cio-sites/components/blocks/b.001/globalheader/modules/navteaser&#34;,&#34;xdm:linkURL&#34;:&#34;/us-en/insights/voices&#34;,&#34;analytics-module-name&#34;:&#34;navteaser-1&#34;}}" data-mark-type="cio-sites/components/blocks/b.001/globalheader/modules/navteaser" data-mark-nodepath="/content/experience-fragments/acom/us-en/header/primary-navigation/insights/master/jcr:content/root/navcontainer/first/navteaser" data-mark-instance="navteaser">
	
    
	
    <div class="cmp-teaser__content">
        
    <div class="cmp-teaser__pretitle">
		
		
			FEATURED CONTENT
		
		</div>
	
 	

        
    <h2 class="cmp-teaser__title" data-mark="jcr:title">
		
        <a class="cmp-teaser__title-link" href="/us-en/insights/voices" target="_self" aria-label="Voices of change" data-cmp-data-layer="{&#34;navteaser-46978c3ab1-title&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/insights/voices&#34;,&#34;analytics-link-name&#34;:&#34;Voices of Change&#34;}}" data-cmp-clickable>Voices of Change</a>
    </h2>

        
	<div class="cmp-teaser__description" data-mark="jcr:description"><p><span class="cmp-text__paragraph-medium">The path to 360° value starts here—featuring our most provocative thinking, extensive research and compelling stories of shared success.</span></p>
</div>

        
    

    </div>
</div>

    
</div>

    
</div>
</div>

            
         </div>
         <div class="cmp-global-header__drawer-right-column">
         	<div class="cmp-global-header__group-link-list">
            
               <div class="responsivegrid">


<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
    
    <div class="cmp-global-header__link-list aem-GridColumn aem-GridColumn--default--12"><div id="linklistteaser-474a653977" class="cmp-global-header__link-list" data-cmp-data-layer="{&#34;linklistteaser-474a653977&#34;:{&#34;@type&#34;:&#34;cio-sites/components/blocks/b.001/globalheader/modules/linklistteaser&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-module-name&#34;:&#34;secondary nav&#34;,&#34;analytics-template-zone&#34;:&#34;global header&#34;}}">
	<div class="cmp-global-header__link-list__content">
	
	<div>
      
	  <ul class="cmp-global-header__inner-link-list" role="menu" aria-label="Insights">
        <li role="none">
          <a href="/us-en/insights/5g-index" aria-label="5G" data-cmp-data-layer="{&#34;linklistteaser-item0-6fda68ed03&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/insights/5g-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;insights:5g&#34;}}" role="menuitem" data-cmp-clickable>5G
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/insights/artificial-intelligence-summary-index" aria-label="Artificial Intelligence" data-cmp-data-layer="{&#34;linklistteaser-item1-2249889e25&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/insights/artificial-intelligence-summary-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;insights:artificial intelligence&#34;}}" role="menuitem" data-cmp-clickable>Artificial Intelligence
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/insights/blockchain-index" aria-label="Blockchain" data-cmp-data-layer="{&#34;linklistteaser-item2-fb977a4737&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/insights/blockchain-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;insights:blockchain&#34;}}" role="menuitem" data-cmp-clickable>Blockchain
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/insights/cloud-insights" aria-label="Cloud" data-cmp-data-layer="{&#34;linklistteaser-item3-4a5bce647a&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/insights/cloud-insights&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;insights:cloud &#34;}}" role="menuitem" data-cmp-clickable>Cloud 
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/insights/song/customer-experience-index" aria-label="CX" data-cmp-data-layer="{&#34;linklistteaser-item4-777b9a6974&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/insights/song/customer-experience-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;insights:customer experience&#34;}}" role="menuitem" data-cmp-clickable>Customer Experience
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/insights/cyber-security-index" aria-label="cyber security" data-cmp-data-layer="{&#34;linklistteaser-item5-6c4d72c3f7&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/insights/cyber-security-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;insights:cybersecurity&#34;}}" role="menuitem" data-cmp-clickable>Cybersecurity
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/insights/industry-x-index" aria-label="Digital Engineering &amp; Manufacturing" data-cmp-data-layer="{&#34;linklistteaser-item6-52564b1b8a&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/insights/industry-x-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;insights:digital engineering &amp; manufacturing&#34;}}" role="menuitem" data-cmp-clickable>Digital Engineering &amp; Manufacturing
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/insights/digital-transformation-index" aria-label="digital transformation" data-cmp-data-layer="{&#34;linklistteaser-item7-57bdc79afb&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/insights/digital-transformation-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;insights:digital transformation&#34;}}" role="menuitem" data-cmp-clickable>Digital Transformation
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/insights/cloud/edge-computing-index" aria-label="Edge Computing" data-cmp-data-layer="{&#34;linklistteaser-item8-56fc89a268&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/insights/cloud/edge-computing-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;insights:edge computing&#34;}}" role="menuitem" data-cmp-clickable>Edge Computing
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/insightsnew/future-workforce-index" aria-label="Future of Work" data-cmp-data-layer="{&#34;linklistteaser-item9-812ee8e08f&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/insightsnew/future-workforce-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;insights:future of work&#34;}}" role="menuitem" data-cmp-clickable>Future of Work
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/insights/generative-ai" aria-label="Generative AI" data-cmp-data-layer="{&#34;linklistteaser-item10-2c42decc0b&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/insights/generative-ai&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;insights:generative ai&#34;}}" role="menuitem" data-cmp-clickable>Generative AI
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/insights/metaverse" aria-label="Metaverse " data-cmp-data-layer="{&#34;linklistteaser-item11-006b1827d8&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/insights/metaverse&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;insights:metaverse &#34;}}" role="menuitem" data-cmp-clickable>Metaverse 
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/insights/supply-chain-operations/supply-chain-management-operations-index" aria-label="Supply Chain Insights" data-cmp-data-layer="{&#34;linklistteaser-item12-2d25313d11&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/insights/supply-chain-operations/supply-chain-management-operations-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;insights:supply chain&#34;}}" role="menuitem" data-cmp-clickable>Supply Chain
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/insights/consulting/sustainability-index" aria-label="Sustainability" data-cmp-data-layer="{&#34;linklistteaser-item13-3580c06fc6&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/insights/consulting/sustainability-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;insights:sustainability&#34;}}" role="menuitem" data-cmp-clickable>Sustainability
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/insights/podcast-index" aria-label="pod" data-cmp-data-layer="{&#34;linklistteaser-item14-e0847e07c8&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/insights/podcast-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;insights:podcasts&#34;}}" role="menuitem" data-cmp-clickable>Podcasts
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/insights/blogs-index" aria-label="blogs" data-cmp-data-layer="{&#34;linklistteaser-item15-919d3704a6&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/insights/blogs-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;insights:blogs&#34;}}" role="menuitem" data-cmp-clickable>Blogs
			  
		  </a>
        </li>
      </ul>
    </div>
  </div>
</div>


    
</div>

    
</div>
</div>

            
            </div>
         </div>
      </div>
      <!-- End Two Container -->
      <!-- Begin One Container -->
	  	
	 <!-- End One Container -->
   </div>
</div>
<!-- end:  --></div>

    
</div>

    </div>

    
</div>

              </div>
            </li>
              
          
              <li class="cmp-global-header__nav-menu-item" id="globalheader-primarynavlinks-item1-757e52e9b1" data-cmp-data-layer="{&#34;globalheader-primarynavlinks-item1-757e52e9b1&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/errors/404&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;Services&#34;,&#34;analytics-module-name&#34;:&#34;primary nav&#34;}}">
              <button class="cmp-global-header__nav-menu-label-button" type="button" aria-expanded="false" aria-haspopup="true" aria-label="Services">Services</button>
              <div class="cmp-global-header__nav-menu-item-content">
                    <div class="xfpage page basicpage">


    
    <div id="container-b0849484bb" class="cmp-container">
        


<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
    
    <div class="navcontainer container responsivegrid aem-GridColumn aem-GridColumn--default--12"><!-- Begin Nav Container -->
<div class="cmp-global-header__drawer">
   <div class="cmp-global-header__drawer-content">
      
      <!-- End Two Container -->
      <!-- Begin One Container -->
	  	<div class="cmp-global-header__drawer-one-column">
	  		<div class="cmp-global-header__group-link-list">
	  			
               		<div class="responsivegrid">


<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
    
    <div class="cmp-global-header__link-list aem-GridColumn aem-GridColumn--default--12"><div id="linklistteaser-8e1c7f9581" class="cmp-global-header__link-list" data-cmp-data-layer="{&#34;linklistteaser-8e1c7f9581&#34;:{&#34;@type&#34;:&#34;cio-sites/components/blocks/b.001/globalheader/modules/linklistteaser&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-module-name&#34;:&#34;secondary nav&#34;,&#34;analytics-template-zone&#34;:&#34;global header&#34;}}">
	<div class="cmp-global-header__link-list__content">
	
	<div>
      
	  <ul class="cmp-global-header__inner-link-list" role="menu" aria-label="Services">
        <li role="none">
          <a href="/us-en/services/technology/application-services" aria-label="Application Services" data-cmp-data-layer="{&#34;linklistteaser-item0-dfddd700f8&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/technology/application-services&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:application services&#34;}}" role="menuitem" data-cmp-clickable>Application Services
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/services/ai-artificial-intelligence-index" aria-label="Artificial Intelligence" data-cmp-data-layer="{&#34;linklistteaser-item1-8c6d9a0482&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/ai-artificial-intelligence-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:artificial intelligence&#34;}}" role="menuitem" data-cmp-clickable>Artificial Intelligence
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/services/intelligent-automation-index" aria-label="Automation" data-cmp-data-layer="{&#34;linklistteaser-item2-392a4f17d4&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/intelligent-automation-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:automation&#34;}}" role="menuitem" data-cmp-clickable>Automation
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/services/business-process-outsourcing-index" aria-label="Business Process Outsourcing" data-cmp-data-layer="{&#34;linklistteaser-item3-160f001d45&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/business-process-outsourcing-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:business process outsourcing&#34;}}" role="menuitem" data-cmp-clickable>Business Process Outsourcing
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/about/strategy-index" aria-label="Business Strategy" data-cmp-data-layer="{&#34;linklistteaser-item4-ca28017ce7&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/about/strategy-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:business strategy&#34;}}" role="menuitem" data-cmp-clickable>Business Strategy
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/services/talent-organization-human-potential-index" aria-label="Change Management" data-cmp-data-layer="{&#34;linklistteaser-item5-7459c21c7c&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/talent-organization-human-potential-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:change management&#34;}}" role="menuitem" data-cmp-clickable>Change Management
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/cloud/services-index" aria-label="Cloud" data-cmp-data-layer="{&#34;linklistteaser-item6-a8568420fc&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/cloud/services-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:cloud&#34;}}" role="menuitem" data-cmp-clickable>Cloud
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/about/song-company-index" aria-label="Customer Experience" data-cmp-data-layer="{&#34;linklistteaser-item7-ef816433e8&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/about/song-company-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:customer experience&#34;}}" role="menuitem" data-cmp-clickable>Customer Experience
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/services/data-analytics-index" aria-label="Data &amp; Analytics" data-cmp-data-layer="{&#34;linklistteaser-item8-3559be347b&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/data-analytics-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:data &amp; analytics&#34;}}" role="menuitem" data-cmp-clickable>Data &amp; Analytics
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/services/song/commerce-transformation" aria-label="Digital Commerce" data-cmp-data-layer="{&#34;linklistteaser-item9-0f5946b3f5&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/song/commerce-transformation&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:digital commerce&#34;}}" role="menuitem" data-cmp-clickable>Digital Commerce
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/services/digital-engineering-manufacturing-index" aria-label="Digital Engineering &amp; Manufacturing" data-cmp-data-layer="{&#34;linklistteaser-item10-db524fc199&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/digital-engineering-manufacturing-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:digital engineering &amp; manufacturing&#34;}}" role="menuitem" data-cmp-clickable>Digital Engineering &amp; Manufacturing
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/services/technology/enterprise-industry-technologies" aria-label="Enterprise Platforms" data-cmp-data-layer="{&#34;linklistteaser-item11-4bed802622&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/technology/enterprise-industry-technologies&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:enterprise platforms&#34;}}" role="menuitem" data-cmp-clickable>Enterprise Platforms
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/services/cfo-and-enterprise-value-index" aria-label="Finance Consulting" data-cmp-data-layer="{&#34;linklistteaser-item12-32f9b89aa3&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/cfo-and-enterprise-value-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:finance consulting&#34;}}" role="menuitem" data-cmp-clickable>Finance Consulting
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/cloud/services/infrastructure-index" aria-label="Infrastructure" data-cmp-data-layer="{&#34;linklistteaser-item13-5e7e78e0c2&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/cloud/services/infrastructure-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:infrastructure&#34;}}" role="menuitem" data-cmp-clickable>Infrastructure
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/services/song/marketing-transformation" aria-label="Marketing" data-cmp-data-layer="{&#34;linklistteaser-item14-813995d886&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/song/marketing-transformation&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:marketing&#34;}}" role="menuitem" data-cmp-clickable>Marketing
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/services/mergers-acquisitions-index" aria-label="Mergers &amp; Acquisitions (M&amp;A)" data-cmp-data-layer="{&#34;linklistteaser-item15-2d83199549&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/mergers-acquisitions-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:mergers &amp; acquisitions (m&amp;a)&#34;}}" role="menuitem" data-cmp-clickable>Mergers &amp; Acquisitions (M&amp;A)
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/services/metaverse-index" aria-label="Metaverse" data-cmp-data-layer="{&#34;linklistteaser-item16-9728d4ef91&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/metaverse-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:metaverse&#34;}}" role="menuitem" data-cmp-clickable>Metaverse
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/services/talent-organization/future-organization" aria-label="Operating Models" data-cmp-data-layer="{&#34;linklistteaser-item17-5f7ef61293&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/talent-organization/future-organization&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:operating models&#34;}}" role="menuitem" data-cmp-clickable>Operating Models
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/services/security-index" aria-label="Security" data-cmp-data-layer="{&#34;linklistteaser-item18-f67ecc4d35&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/security-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:security&#34;}}" role="menuitem" data-cmp-clickable>Security
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/services/supply-chain-management-and-operations-index" aria-label="Supply Chain Management" data-cmp-data-layer="{&#34;linklistteaser-item19-ff9a66563c&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/supply-chain-management-and-operations-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:supply chain management&#34;}}" role="menuitem" data-cmp-clickable>Supply Chain Management
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/services/sustainability-index" aria-label="Sustainability" data-cmp-data-layer="{&#34;linklistteaser-item20-b4f7c1476a&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/sustainability-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:sustainability&#34;}}" role="menuitem" data-cmp-clickable>Sustainability
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/services/consulting/technology-consulting" aria-label="Technology ConsultingTechnology Consulting" data-cmp-data-layer="{&#34;linklistteaser-item21-418295f4eb&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/consulting/technology-consulting&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:technology consulting&#34;}}" role="menuitem" data-cmp-clickable>Technology Consulting
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/services/technology-innovation-index" aria-label="Technology Innovation" data-cmp-data-layer="{&#34;linklistteaser-item22-7ffaaaa2c6&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/technology-innovation-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:technology innovation&#34;}}" role="menuitem" data-cmp-clickable>Technology Innovation
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/services/zero-based-budgeting-index" aria-label="Zero-Based Transformation" data-cmp-data-layer="{&#34;linklistteaser-item23-a62355303a&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/services/zero-based-budgeting-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;services:zero-based transformation&#34;}}" role="menuitem" data-cmp-clickable>Zero-Based Transformation
			  
		  </a>
        </li>
      </ul>
    </div>
  </div>
</div>


    
</div>

    
</div>
</div>

            	
            </div>
	 	</div>
	 <!-- End One Container -->
   </div>
</div>
<!-- end:  --></div>

    
</div>

    </div>

    
</div>

              </div>
            </li>
              
          
              <li class="cmp-global-header__nav-menu-item" id="globalheader-primarynavlinks-item2-dc2a44143e" data-cmp-data-layer="{&#34;globalheader-primarynavlinks-item2-dc2a44143e&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/errors/404&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;Industries&#34;,&#34;analytics-module-name&#34;:&#34;primary nav&#34;}}">
              <button class="cmp-global-header__nav-menu-label-button" type="button" aria-expanded="false" aria-haspopup="true" aria-label="Industries">Industries</button>
              <div class="cmp-global-header__nav-menu-item-content">
                    <div class="xfpage page basicpage">


    
    <div id="container-4666a53707" class="cmp-container">
        


<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
    
    <div class="navcontainer container responsivegrid aem-GridColumn aem-GridColumn--default--12"><!-- Begin Nav Container -->
<div class="cmp-global-header__drawer">
   <div class="cmp-global-header__drawer-content">
      
      <!-- End Two Container -->
      <!-- Begin One Container -->
	  	<div class="cmp-global-header__drawer-one-column">
	  		<div class="cmp-global-header__group-link-list">
	  			
               		<div class="responsivegrid">


<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
    
    <div class="cmp-global-header__link-list aem-GridColumn aem-GridColumn--default--12"><div id="linklistteaser-70733c5050" class="cmp-global-header__link-list" data-cmp-data-layer="{&#34;linklistteaser-70733c5050&#34;:{&#34;@type&#34;:&#34;cio-sites/components/blocks/b.001/globalheader/modules/linklistteaser&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-module-name&#34;:&#34;secondary nav&#34;,&#34;analytics-template-zone&#34;:&#34;global header&#34;}}">
	<div class="cmp-global-header__link-list__content">
	
	<div>
      
	  <ul class="cmp-global-header__inner-link-list" role="menu" aria-label="Industries">
        <li role="none">
          <a href="/us-en/industries/aerospace-defense-index" aria-label="Utilities" data-cmp-data-layer="{&#34;linklistteaser-item0-d468081cb3&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/aerospace-defense-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries:aerospace and defense&#34;}}" role="menuitem" data-cmp-clickable>Aerospace and Defense
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/industries/automotive-index" aria-label="Automotive" data-cmp-data-layer="{&#34;linklistteaser-item1-0e0719f65c&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/automotive-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries:automotive&#34;}}" role="menuitem" data-cmp-clickable>Automotive
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/industries/banking-index" aria-label=" Banking" data-cmp-data-layer="{&#34;linklistteaser-item2-b02905f170&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/banking-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries: banking&#34;}}" role="menuitem" data-cmp-clickable> Banking
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/industries/capital-markets-index" aria-label=" Capital Markets" data-cmp-data-layer="{&#34;linklistteaser-item3-cd55229f7c&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/capital-markets-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries: capital markets&#34;}}" role="menuitem" data-cmp-clickable> Capital Markets
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/industries/chemicals-index" aria-label="Chemicals" data-cmp-data-layer="{&#34;linklistteaser-item4-8c801cf62e&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/chemicals-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries:chemicals&#34;}}" role="menuitem" data-cmp-clickable>Chemicals
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/industries/communications-and-media-index" aria-label=" Communications and Media" data-cmp-data-layer="{&#34;linklistteaser-item5-574e0523d1&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/communications-and-media-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries: communications and media&#34;}}" role="menuitem" data-cmp-clickable> Communications and Media
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/industries/consumer-goods-and-services-index" aria-label=" Consumer Goods and Services" data-cmp-data-layer="{&#34;linklistteaser-item6-b27f5ac1b4&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/consumer-goods-and-services-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries: consumer goods and services&#34;}}" role="menuitem" data-cmp-clickable> Consumer Goods and Services
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/industries/energy-index" aria-label=" Energy" data-cmp-data-layer="{&#34;linklistteaser-item7-083100b2dd&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/energy-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries: energy&#34;}}" role="menuitem" data-cmp-clickable> Energy
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/industries/health-index" aria-label="Health" data-cmp-data-layer="{&#34;linklistteaser-item8-78ef10acfa&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/health-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries:health&#34;}}" role="menuitem" data-cmp-clickable>Health
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/industries/high-tech-index" aria-label=" High Tech" data-cmp-data-layer="{&#34;linklistteaser-item9-4fa15f0a6d&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/high-tech-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries: high tech&#34;}}" role="menuitem" data-cmp-clickable> High Tech
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/industries/industrial-equipment-index" aria-label=" Industrial" data-cmp-data-layer="{&#34;linklistteaser-item10-96402e2eaf&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/industrial-equipment-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries: industrial&#34;}}" role="menuitem" data-cmp-clickable> Industrial
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/industries/insurance-index" aria-label=" Insurance" data-cmp-data-layer="{&#34;linklistteaser-item11-c883ce119b&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/insurance-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries: insurance&#34;}}" role="menuitem" data-cmp-clickable> Insurance
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/industries/life-sciences-index" aria-label="Life Sciences" data-cmp-data-layer="{&#34;linklistteaser-item12-6c4c282475&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/life-sciences-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries:life sciences&#34;}}" role="menuitem" data-cmp-clickable>Life Sciences
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/industries/natural-resources-index" aria-label="Natural Resources" data-cmp-data-layer="{&#34;linklistteaser-item13-bcfa4c1917&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/natural-resources-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries:natural resources&#34;}}" role="menuitem" data-cmp-clickable>Natural Resources
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/industries/public-service-index" aria-label=" Public Service" data-cmp-data-layer="{&#34;linklistteaser-item14-167ae6356b&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/public-service-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries: public service&#34;}}" role="menuitem" data-cmp-clickable> Public Service
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/industries/retail-index" aria-label=" Retail" data-cmp-data-layer="{&#34;linklistteaser-item15-71c5d6d4cc&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/retail-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries: retail&#34;}}" role="menuitem" data-cmp-clickable> Retail
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/industries/software-and-platforms-index" aria-label="Software and Platforms" data-cmp-data-layer="{&#34;linklistteaser-item16-0f8a6fa771&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/software-and-platforms-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries:software and platforms&#34;}}" role="menuitem" data-cmp-clickable>Software and Platforms
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/industries/travel-index" aria-label=" Travel" data-cmp-data-layer="{&#34;linklistteaser-item17-154db2b31b&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/travel-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries: travel&#34;}}" role="menuitem" data-cmp-clickable> Travel
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/industries/afs-index" aria-label="US Federal Government" data-cmp-data-layer="{&#34;linklistteaser-item18-588296021f&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/afs-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries:us federal government&#34;}}" role="menuitem" data-cmp-clickable>US Federal Government
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/industries/utilities-index" aria-label="Utilities" data-cmp-data-layer="{&#34;linklistteaser-item19-3f02af62d9&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/industries/utilities-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;industries:utilities&#34;}}" role="menuitem" data-cmp-clickable>Utilities
			  
		  </a>
        </li>
      </ul>
    </div>
  </div>
</div>


    
</div>

    
</div>
</div>

            	
            </div>
	 	</div>
	 <!-- End One Container -->
   </div>
</div>
<!-- end:  --></div>

    
</div>

    </div>

    
</div>

              </div>
            </li>
              
          
              <li class="cmp-global-header__nav-menu-item" id="globalheader-primarynavlinks-item3-7d0ef1505c" data-cmp-data-layer="{&#34;globalheader-primarynavlinks-item3-7d0ef1505c&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/errors/404&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;Careers&#34;,&#34;analytics-module-name&#34;:&#34;primary nav&#34;}}">
              <button class="cmp-global-header__nav-menu-label-button" type="button" aria-expanded="false" aria-haspopup="true" aria-label="Careers">Careers</button>
              <div class="cmp-global-header__nav-menu-item-content">
                    <div class="xfpage page basicpage">


    
    <div id="container-f0eaabf117" class="cmp-container">
        


<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
    
    <div class="navcontainer container responsivegrid aem-GridColumn aem-GridColumn--default--12"><!-- Begin Nav Container -->
<div class="cmp-global-header__drawer">
   <div class="cmp-global-header__drawer-content">
      
      <!-- End Two Container -->
      <!-- Begin One Container -->
	  	<div class="cmp-global-header__drawer-one-column">
	  		<div class="cmp-global-header__group-link-list">
	  			
               		<div class="responsivegrid">


<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
    
    <div class="cmp-global-header__link-list cmp-global-header__link-list--with-arrows aem-GridColumn aem-GridColumn--default--12"><div id="linklistteaser-5144a6033d" class="cmp-global-header__link-list" data-cmp-data-layer="{&#34;linklistteaser-5144a6033d&#34;:{&#34;@type&#34;:&#34;cio-sites/components/blocks/b.001/globalheader/modules/linklistteaser&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-module-name&#34;:&#34;secondary nav&#34;,&#34;analytics-template-zone&#34;:&#34;global header&#34;}}">
	<div class="cmp-global-header__link-list__content">
	
	<div>
      
	  <ul class="cmp-global-header__inner-link-list" role="menu" aria-label="Careers">
        <li role="none">
          <a href="/us-en/careers" aria-label="Careers Home" data-cmp-data-layer="{&#34;linklistteaser-item0-b8682ccf2c&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:careers home&#34;}}" role="menuitem" data-cmp-clickable>Careers Home
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/jobsearch" aria-label="Search Jobs" data-cmp-data-layer="{&#34;linklistteaser-item1-0bbea7dba2&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/jobsearch&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:search jobs&#34;}}" role="menuitem" data-cmp-clickable>Search Jobs
			  
		  </a>
        </li>
      </ul>
    </div>
  </div>
</div>


    
</div>
<div class="cmp-global-header__link-list aem-GridColumn aem-GridColumn--default--12"><div id="linklistteaser-a1fc2a07ab" class="cmp-global-header__title-link-list" data-cmp-data-layer="{&#34;linklistteaser-a1fc2a07ab&#34;:{&#34;@type&#34;:&#34;cio-sites/components/blocks/b.001/globalheader/modules/linklistteaser&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-module-name&#34;:&#34;secondary nav&#34;,&#34;analytics-template-zone&#34;:&#34;global header&#34;}}">
	<div class="cmp-global-header__title-link-list__menu">
	
		<p class="cmp-global-header__title-link-list__menu-label">JOIN US</p>
    <button class="cmp-global-header__title-link-list__menu-button" type="button">JOIN US</button>
    
	<div class="cmp-global-header__title-link-list__content">
      <button class="cmp-global-header__title-link-list__content-button" type="button">Careers</button>
	  <ul class="cmp-global-header__inner-link-list" role="menu" aria-label="Careers">
        <li role="none">
          <a href="/us-en/careers/life-at-accenture/leadership-careers" aria-label="Search and Apply" data-cmp-data-layer="{&#34;linklistteaser_417516962-item0-edc67ebfa0&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/life-at-accenture/leadership-careers&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:executive leaders&#34;}}" role="menuitem" data-cmp-clickable>Executive Leaders
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/life-at-accenture/experienced" aria-label="Experienced Professionals" data-cmp-data-layer="{&#34;linklistteaser_417516962-item1-1d1911d086&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/life-at-accenture/experienced&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:experienced professionals&#34;}}" role="menuitem" data-cmp-clickable>Experienced Professionals
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/life-at-accenture/entry-level" aria-label="Entry-level Jobs &amp; Internships" data-cmp-data-layer="{&#34;linklistteaser_417516962-item2-612b07eab9&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/life-at-accenture/entry-level&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:entry-level jobs &amp; internships&#34;}}" role="menuitem" data-cmp-clickable>Entry-level Jobs &amp; Internships
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/local/military-veterans" data-cmp-data-layer="{&#34;linklistteaser_417516962-item3-accfbc75a4&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/local/military-veterans&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:military and veterans&#34;}}" role="menuitem" data-cmp-clickable>Military and Veterans
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/life-at-accenture/training-counseling" aria-label="Training &amp; Development" data-cmp-data-layer="{&#34;linklistteaser_417516962-item4-377bfdce2c&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/life-at-accenture/training-counseling&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:training &amp; development&#34;}}" role="menuitem" data-cmp-clickable>Training &amp; Development
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/explore-careers/area-of-interest/journey-to-accenture" aria-label="Work Environment" data-cmp-data-layer="{&#34;linklistteaser_417516962-item5-e9ebe38407&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/explore-careers/area-of-interest/journey-to-accenture&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:recruiting process&#34;}}" role="menuitem" data-cmp-clickable>Recruiting Process
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/local/total-rewards" data-cmp-data-layer="{&#34;linklistteaser_417516962-item6-fec4382ed4&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/local/total-rewards&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:rewards &amp; benefits&#34;}}" role="menuitem" data-cmp-clickable>Rewards &amp; Benefits
			  
		  </a>
        </li>
      </ul>
    </div>
  </div>
</div>


    
</div>
<div class="cmp-global-header__link-list cmp-global-header__link-list--full-width-li aem-GridColumn aem-GridColumn--default--12"><div id="linklistteaser-8d64b1a31d" class="cmp-global-header__title-link-list" data-cmp-data-layer="{&#34;linklistteaser-8d64b1a31d&#34;:{&#34;@type&#34;:&#34;cio-sites/components/blocks/b.001/globalheader/modules/linklistteaser&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-module-name&#34;:&#34;secondary nav&#34;,&#34;analytics-template-zone&#34;:&#34;global header&#34;}}">
	<div class="cmp-global-header__title-link-list__menu">
	
		<p class="cmp-global-header__title-link-list__menu-label">EXPLORE JOBS</p>
    <button class="cmp-global-header__title-link-list__menu-button" type="button">EXPLORE JOBS</button>
    
	<div class="cmp-global-header__title-link-list__content">
      <button class="cmp-global-header__title-link-list__content-button" type="button">Careers</button>
	  <ul class="cmp-global-header__inner-link-list" role="menu" aria-label="Careers">
        <li role="none">
          <a href="/us-en/careers/explore-careers/areas-of-interest/areas-expertise" aria-label="Search Jobs by Areas of Expertise" data-cmp-data-layer="{&#34;linklistteaser_159490398-item0-c2c57152cb&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/explore-careers/areas-of-interest/areas-expertise&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:search jobs by areas of expertise&#34;}}" role="menuitem" data-cmp-clickable>Search Jobs by Areas of Expertise
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/explore-careers/area-of-interest/consulting-careers" aria-label="Consulting Jobs" data-cmp-data-layer="{&#34;linklistteaser_159490398-item1-06c80aa552&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/explore-careers/area-of-interest/consulting-careers&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:consulting jobs&#34;}}" role="menuitem" data-cmp-clickable>Consulting Jobs
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/explore-careers/area-of-interest/corporate-functions-careers" aria-label="Corporate Jobs" data-cmp-data-layer="{&#34;linklistteaser_159490398-item2-dceb40a0f5&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/explore-careers/area-of-interest/corporate-functions-careers&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:corporate jobs&#34;}}" role="menuitem" data-cmp-clickable>Corporate Jobs
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/explore-careers/area-of-interest/interactive-careers" aria-label="Digital Jobs" data-cmp-data-layer="{&#34;linklistteaser_159490398-item3-b6086af03a&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/explore-careers/area-of-interest/interactive-careers&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:digital jobs&#34;}}" role="menuitem" data-cmp-clickable>Digital Jobs
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/explore-careers/area-of-interest/industryx-careers" aria-label="Digital Engineering and Manufacturing Jobs" data-cmp-data-layer="{&#34;linklistteaser_159490398-item4-3f683bc333&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/explore-careers/area-of-interest/industryx-careers&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:digital engineering and manufacturing jobs&#34;}}" role="menuitem" data-cmp-clickable>Digital Engineering and Manufacturing Jobs
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/explore-careers/area-of-interest/operations-careers" aria-label="Operations Jobs" data-cmp-data-layer="{&#34;linklistteaser_159490398-item5-611efcbdf9&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/explore-careers/area-of-interest/operations-careers&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:operations jobs&#34;}}" role="menuitem" data-cmp-clickable>Operations Jobs
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/explore-careers/area-of-interest/strategy-careers" aria-label="Strategy Jobs" data-cmp-data-layer="{&#34;linklistteaser_159490398-item6-608ef1f2a3&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/explore-careers/area-of-interest/strategy-careers&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:strategy jobs&#34;}}" role="menuitem" data-cmp-clickable>Strategy Jobs
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/explore-careers/area-of-interest/metaverse-careers" aria-label="Metaverse Jobs" data-cmp-data-layer="{&#34;linklistteaser_159490398-item7-3dec1b7d3e&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/explore-careers/area-of-interest/metaverse-careers&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:metaverse jobs&#34;}}" role="menuitem" data-cmp-clickable>Metaverse Jobs
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/explore-careers/area-of-interest/technology-careers" aria-label="Technology Jobs" data-cmp-data-layer="{&#34;linklistteaser_159490398-item8-1145baf19a&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/explore-careers/area-of-interest/technology-careers&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:technology jobs&#34;}}" role="menuitem" data-cmp-clickable>Technology Jobs
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/explore-careers/area-of-interest/ai-and-analytics-careers" aria-label="AI Jobs" data-cmp-data-layer="{&#34;linklistteaser_159490398-item9-588ff53e70&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/explore-careers/area-of-interest/ai-and-analytics-careers&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:ai jobs&#34;}}" role="menuitem" data-cmp-clickable>AI Jobs
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/explore-careers/area-of-interest/cloud-careers" aria-label="Cloud Jobs" data-cmp-data-layer="{&#34;linklistteaser_159490398-item10-f8f099b5bf&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/explore-careers/area-of-interest/cloud-careers&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:cloud jobs&#34;}}" role="menuitem" data-cmp-clickable>Cloud Jobs
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/explore-careers/area-of-interest/cybersecurity-careers" aria-label="Cybersecurity Jobs" data-cmp-data-layer="{&#34;linklistteaser_159490398-item11-8f26da3e03&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/explore-careers/area-of-interest/cybersecurity-careers&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:cybersecurity jobs&#34;}}" role="menuitem" data-cmp-clickable>Cybersecurity Jobs
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/local/federal-careers" aria-label="Federal Jobs" data-cmp-data-layer="{&#34;linklistteaser_159490398-item12-c946264c57&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/local/federal-careers&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:federal jobs&#34;}}" role="menuitem" data-cmp-clickable>Federal Jobs
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/explore-careers/area-of-interest/sap-careers" aria-label="SAP Jobs" data-cmp-data-layer="{&#34;linklistteaser_159490398-item13-7bd7774f59&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/explore-careers/area-of-interest/sap-careers&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:sap jobs&#34;}}" role="menuitem" data-cmp-clickable>SAP Jobs
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/careers/explore-careers/area-of-interest/salesforce-careers" aria-label="Salesforce Jobs" data-cmp-data-layer="{&#34;linklistteaser_159490398-item14-8356e02bc9&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers/explore-careers/area-of-interest/salesforce-careers&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;careers:salesforce jobs&#34;}}" role="menuitem" data-cmp-clickable>Salesforce Jobs
			  
		  </a>
        </li>
      </ul>
    </div>
  </div>
</div>


    
</div>

    
</div>
</div>

            	
            </div>
	 	</div>
	 <!-- End One Container -->
   </div>
</div>
<!-- end:  --></div>

    
</div>

    </div>

    
</div>

              </div>
            </li>
              
          
              <li class="cmp-global-header__nav-menu-item" id="globalheader-primarynavlinks-item4-14edc09979" data-cmp-data-layer="{&#34;globalheader-primarynavlinks-item4-14edc09979&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/errors/404&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;About Accenture&#34;,&#34;analytics-module-name&#34;:&#34;primary nav&#34;}}">
              <button class="cmp-global-header__nav-menu-label-button" type="button" aria-expanded="false" aria-haspopup="true" aria-label="About Accenture">About Accenture</button>
              <div class="cmp-global-header__nav-menu-item-content">
                    <div class="xfpage page basicpage">


    
    <div id="container-ed85557b4b" class="cmp-container">
        


<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
    
    <div class="navcontainer container responsivegrid aem-GridColumn aem-GridColumn--default--12"><!-- Begin Nav Container -->
<div class="cmp-global-header__drawer">
   <div class="cmp-global-header__drawer-content">
      
      <!-- End Two Container -->
      <!-- Begin One Container -->
	  	<div class="cmp-global-header__drawer-one-column">
	  		<div class="cmp-global-header__group-link-list">
	  			
               		<div class="responsivegrid">


<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
    
    <div class="cmp-global-header__link-list aem-GridColumn aem-GridColumn--default--12"><div id="linklistteaser-4c4ed63ac1" class="cmp-global-header__title-link-list" data-cmp-data-layer="{&#34;linklistteaser-4c4ed63ac1&#34;:{&#34;@type&#34;:&#34;cio-sites/components/blocks/b.001/globalheader/modules/linklistteaser&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-module-name&#34;:&#34;secondary nav&#34;,&#34;analytics-template-zone&#34;:&#34;global header&#34;}}">
	<div class="cmp-global-header__title-link-list__menu">
	
		<p class="cmp-global-header__title-link-list__menu-label">WHO WE ARE</p>
    <button class="cmp-global-header__title-link-list__menu-button" type="button">WHO WE ARE</button>
    
	<div class="cmp-global-header__title-link-list__content">
      <button class="cmp-global-header__title-link-list__content-button" type="button">About Accenture</button>
	  <ul class="cmp-global-header__inner-link-list" role="menu" aria-label="About Accenture">
        <li role="none">
          <a href="/us-en/about/company-index" aria-label="About Accenture" data-cmp-data-layer="{&#34;linklistteaser-item0-a95890b2e4&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/about/company-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;about accenture:about accenture&#34;}}" role="menuitem" data-cmp-clickable>About Accenture
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/about/leadership/leadership-index" aria-label="Leadership" data-cmp-data-layer="{&#34;linklistteaser-item1-7d4c812103&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/about/leadership/leadership-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;about accenture:leadership&#34;}}" role="menuitem" data-cmp-clickable>Leadership
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/about/company/all-stories" aria-label="Case Studies" data-cmp-data-layer="{&#34;linklistteaser-item2-476f238f6f&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/about/company/all-stories&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;about accenture:case studies&#34;}}" role="menuitem" data-cmp-clickable>Case Studies
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="https://newsroom.accenture.com" aria-label="Newsroom" data-cmp-data-layer="{&#34;linklistteaser-item3-8b5d1a6c57&#34;:{&#34;xdm:linkURL&#34;:&#34;https://newsroom.accenture.com&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;about accenture:newsroom&#34;}}" role="menuitem" data-cmp-clickable>Newsroom
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="https://investor.accenture.com/" aria-label="Investor Relations" data-cmp-data-layer="{&#34;linklistteaser-item4-885c82e8c4&#34;:{&#34;xdm:linkURL&#34;:&#34;https://investor.accenture.com/&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;about accenture:investor relations&#34;}}" role="menuitem" data-cmp-clickable>Investor Relations
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/about/inclusion-diversity-index" aria-label="Inclusion &amp; Diversity" data-cmp-data-layer="{&#34;linklistteaser-item5-9c6cb94ac5&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/about/inclusion-diversity-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;about accenture:inclusion &amp; diversity&#34;}}" role="menuitem" data-cmp-clickable>Inclusion &amp; Diversity
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/about/sustainability/sustainability-value-promise" aria-label="Responsible Business" data-cmp-data-layer="{&#34;linklistteaser-item6-8c9e4fae2f&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/about/sustainability/sustainability-value-promise&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;about accenture:sustainability&#34;}}" role="menuitem" data-cmp-clickable>Sustainability
			  
		  </a>
        </li>
      </ul>
    </div>
  </div>
</div>


    
</div>
<div class="cmp-global-header__link-list aem-GridColumn aem-GridColumn--default--12"><div id="linklistteaser-1c61ea3168" class="cmp-global-header__title-link-list" data-cmp-data-layer="{&#34;linklistteaser-1c61ea3168&#34;:{&#34;@type&#34;:&#34;cio-sites/components/blocks/b.001/globalheader/modules/linklistteaser&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-module-name&#34;:&#34;secondary nav&#34;,&#34;analytics-template-zone&#34;:&#34;global header&#34;}}">
	<div class="cmp-global-header__title-link-list__menu">
	
		<p class="cmp-global-header__title-link-list__menu-label">HOW WE&#39;RE ORGANIZED</p>
    <button class="cmp-global-header__title-link-list__menu-button" type="button">HOW WE&#39;RE ORGANIZED</button>
    
	<div class="cmp-global-header__title-link-list__content">
      <button class="cmp-global-header__title-link-list__content-button" type="button">About Accenture</button>
	  <ul class="cmp-global-header__inner-link-list" role="menu" aria-label="About Accenture">
        <li role="none">
          <a href="/us-en/about/consulting-index" aria-label="Strategy &amp; Consulting" data-cmp-data-layer="{&#34;linklistteaser_1748804336-item0-bf168425f6&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/about/consulting-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;about accenture:strategy &amp; consulting&#34;}}" role="menuitem" data-cmp-clickable>Strategy &amp; Consulting
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/about/accenture-song-index" aria-label="Song" data-cmp-data-layer="{&#34;linklistteaser_1748804336-item1-d0447cf4b3&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/about/accenture-song-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;about accenture:song&#34;}}" role="menuitem" data-cmp-clickable>Song
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/about/technology-index" aria-label="Technology" data-cmp-data-layer="{&#34;linklistteaser_1748804336-item2-2a38e9e6ec&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/about/technology-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;about accenture:technology&#34;}}" role="menuitem" data-cmp-clickable>Technology
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/about/operations-index" aria-label="Operations" data-cmp-data-layer="{&#34;linklistteaser_1748804336-item3-82213a9c6d&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/about/operations-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;about accenture:operations&#34;}}" role="menuitem" data-cmp-clickable>Operations
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/about/industry-x-index" aria-label="Industry X" data-cmp-data-layer="{&#34;linklistteaser_1748804336-item4-0af8d2bc19&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/about/industry-x-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;about accenture:industry x&#34;}}" role="menuitem" data-cmp-clickable>Industry X
			  
		  </a>
        </li>
      </ul>
    </div>
  </div>
</div>


    
</div>
<div class="cmp-global-header__link-list aem-GridColumn aem-GridColumn--default--12"><div id="linklistteaser-6e9fe263e8" class="cmp-global-header__title-link-list" data-cmp-data-layer="{&#34;linklistteaser-6e9fe263e8&#34;:{&#34;@type&#34;:&#34;cio-sites/components/blocks/b.001/globalheader/modules/linklistteaser&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-module-name&#34;:&#34;secondary nav&#34;,&#34;analytics-template-zone&#34;:&#34;global header&#34;}}">
	<div class="cmp-global-header__title-link-list__menu">
	
		<p class="cmp-global-header__title-link-list__menu-label">IN THE U.S.</p>
    <button class="cmp-global-header__title-link-list__menu-button" type="button">IN THE U.S.</button>
    
	<div class="cmp-global-header__title-link-list__content">
      <button class="cmp-global-header__title-link-list__content-button" type="button">About Accenture</button>
	  <ul class="cmp-global-header__inner-link-list" role="menu" aria-label="About Accenture">
        <li role="none">
          <a href="/us-en/about/company/united-states" aria-label="About Accenture In India" data-cmp-data-layer="{&#34;linklistteaser_537779873-item0-5ad17e1b28&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/about/company/united-states&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;about accenture:about accenture in the u.s.&#34;}}" role="menuitem" data-cmp-clickable>About Accenture In the U.S.
			  
		  </a>
        </li>
      
        <li role="none">
          <a href="/us-en/about/inclusion-diversity/us-workforce" aria-label="Inclusion &amp; Diversity in the U.S." data-cmp-data-layer="{&#34;linklistteaser_537779873-item1-699942be18&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/about/inclusion-diversity/us-workforce&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;about accenture:inclusion &amp; diversity in the u.s.&#34;}}" role="menuitem" data-cmp-clickable>Inclusion &amp; Diversity in the U.S.
			  
		  </a>
        </li>
      </ul>
    </div>
  </div>
</div>


    
</div>
<div class="ghost aem-GridColumn aem-GridColumn--default--12">

</div>

    
</div>
</div>

            	
            </div>
	 	</div>
	 <!-- End One Container -->
   </div>
</div>
<!-- end:  --></div>

    
</div>

    </div>

    
</div>

              </div>
            </li>
              
          </ul>
          <div class="cmp-global-header__menu-footer">
			<ul class="cmp-global-header__utility-links">
                <li data-cmp-data-layer="{&#34;globalheader-megamenufooterlinks-item0-df9b0d337a&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/about/contact-us&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;Contact Us&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                    <a href="/us-en/about/contact-us" aria-label="Contact Us" data-cmp-clickable>Contact Us</a>
                </li>
                
                
            
                <li data-cmp-data-layer="{&#34;globalheader-megamenufooterlinks-item1-80c35e9414&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/careers&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;Careers&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                    <a href="/us-en/careers" aria-label="Careers" data-cmp-clickable>Careers</a>
                </li>
                
                
            
                <li data-cmp-data-layer="{&#34;globalheader-megamenufooterlinks-item2-c25845a8dd&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/about/location-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;Locations&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                    <a href="/us-en/about/location-index" aria-label="Locations" data-cmp-clickable>Locations</a>
                </li>
                
                
            
                
                
                
            
                
                
                
            </ul>

              
              
                  <div class="cmp-global-header__action-container"></div>
              
		    <ul class="cmp-global-header__social-icons">
              <li data-cmp-data-layer="{&#34;globalheader-megamenusociallinks-item0-8382904ae7&#34;:{&#34;xdm:linkURL&#34;:&#34;https://www.linkedin.com/company/accenture&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;linkedin&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
				<a href="https://www.linkedin.com/company/accenture" target="_blank" rel="noopener" title="linkedin" class="cmp-global-header__icon--linkedin" aria-label="linkedin" data-cmp-clickable>
                 </a>
              </li>
            
              <li data-cmp-data-layer="{&#34;globalheader-megamenusociallinks-item1-42a0e074c4&#34;:{&#34;xdm:linkURL&#34;:&#34;https://twitter.com/Accenture_US&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;twitter&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
				<a href="https://twitter.com/Accenture_US" target="_blank" rel="noopener" title="twitter" class="cmp-global-header__icon--twitter" aria-label="twitter" data-cmp-clickable>
                 </a>
              </li>
            
              <li data-cmp-data-layer="{&#34;globalheader-megamenusociallinks-item2-210b490f76&#34;:{&#34;xdm:linkURL&#34;:&#34;https://www.facebook.com/accenture&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;facebook&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
				<a href="https://www.facebook.com/accenture" target="_blank" rel="noopener" title="facebook" class="cmp-global-header__icon--facebook" aria-label="facebook" data-cmp-clickable>
                 </a>
              </li>
            
              <li data-cmp-data-layer="{&#34;globalheader-megamenusociallinks-item3-0b5756651a&#34;:{&#34;xdm:linkURL&#34;:&#34;https://www.instagram.com/accenture/&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;nav/paginate&#34;,&#34;analytics-link-name&#34;:&#34;instagram&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
				<a href="https://www.instagram.com/accenture/" target="_blank" rel="noopener" title="instagram" class="cmp-global-header__icon--instagram" aria-label="instagram" data-cmp-clickable>
                 </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="cmp-global-header__utility-nav">
        
        <div class="cmp-global-header__search" data-cmp-data-layer="{&#34;globalheader-searchLink-742902727d&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/search/ai-search&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;search activity&#34;,&#34;analytics-link-name&#34;:&#34;initiated search - click/tap&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
			<a href="/us-en/search/ai-search" target="_self" aria-label="search-aria" data-cmp-clickable></a>
        </div>
        

		
        
            <div class="cmp-global-header__action-container"></div>
        
		
        <div class="cmp-global-header__language-container">

          
          <button class="cmp-global-header__language-selector" aria-expanded="false" aria-haspopup="listbox" aria-describedby="cmp-global-header__current-country" aria-label="Country and language selector. Current Country: USA">
            <img src="/content/dam/accenture/final/images/graphics/flags/UnitedStates.jpg" alt="USA"/>
            <span class="icon-down-caret"></span>
          </button>
          
          

          <p id="cmp-global-header__current-country">Current Country: United States</p>

          <div class="cmp-global-header__language-options">
            <span class="arrow-up"></span>
            <div class="input-group"></div>
            <div class="country-list">
				<ul class="cmp-global-header__language-menu" role="menu" aria-labelledby="cmp-global-header__current-country">
                <li class="default">Default (English)</li>
                <li class="dropdown-header ucase">All COUNTRIES &amp; LANGUAGES</li>
                <li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item1-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/ar-es&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Argentina (Spanish)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/ar-es" role="menuitem" aria-label="Argentina (Spanish)" data-cmp-clickable>Argentina (Spanish)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item2-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/au-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Australia (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/au-en" role="menuitem" aria-label="Australia (English)" data-cmp-clickable>Australia (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item3-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/at-de&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Austria (German)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/at-de" role="menuitem" aria-label="Austria (German)" data-cmp-clickable>Austria (German)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item4-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/be-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Belgium (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/be-en" role="menuitem" aria-label="Belgium (English)" data-cmp-clickable>Belgium (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item5-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/br-pt&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Brazil (Portuguese)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/br-pt" role="menuitem" aria-label="Brazil (Portuguese)" data-cmp-clickable>Brazil (Portuguese)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item6-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/bg-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Bulgaria (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/bg-en" role="menuitem" aria-label="Bulgaria (English)" data-cmp-clickable>Bulgaria (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item7-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/ca-fr&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Canada (French)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/ca-fr" role="menuitem" aria-label="Canada (French)" data-cmp-clickable>Canada (French)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item8-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/ca-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Canada (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/ca-en" role="menuitem" aria-label="Canada (English)" data-cmp-clickable>Canada (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item9-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/cl-es&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Chile (Spanish)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/cl-es" role="menuitem" aria-label="Chile (Spanish)" data-cmp-clickable>Chile (Spanish)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item10-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/hk-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;China/Hong Kong SAR (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/hk-en" role="menuitem" aria-label="China/Hong Kong SAR (English)" data-cmp-clickable>China/Hong Kong SAR (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item11-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;https://www.accenture.cn/cn-zh&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;China/Mainland (Chinese)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="https://www.accenture.cn/cn-zh" role="menuitem" aria-label="China/Mainland (Chinese)" data-cmp-clickable>China/Mainland (Chinese)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item12-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/cn-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;China/Mainland (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/cn-en" role="menuitem" aria-label="China/Mainland (English)" data-cmp-clickable>China/Mainland (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item13-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/co-es&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Colombia (Spanish)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/co-es" role="menuitem" aria-label="Colombia (Spanish)" data-cmp-clickable>Colombia (Spanish)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item14-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/cr-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Costa Rica (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/cr-en" role="menuitem" aria-label="Costa Rica (English)" data-cmp-clickable>Costa Rica (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item15-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/cz-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Czech Republic (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/cz-en" role="menuitem" aria-label="Czech Republic (English)" data-cmp-clickable>Czech Republic (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item16-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/dk-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Denmark (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/dk-en" role="menuitem" aria-label="Denmark (English)" data-cmp-clickable>Denmark (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item18-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/fi-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Finland (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/fi-en" role="menuitem" aria-label="Finland (English)" data-cmp-clickable>Finland (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item19-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/fr-fr&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;France (French)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/fr-fr" role="menuitem" aria-label="France (French)" data-cmp-clickable>France (French)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item20-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/de-de&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Germany (German)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/de-de" role="menuitem" aria-label="Germany (German)" data-cmp-clickable>Germany (German)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item21-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/gr-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Greece (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/gr-en" role="menuitem" aria-label="Greece (English)" data-cmp-clickable>Greece (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item22-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/hu-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Hungary (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/hu-en" role="menuitem" aria-label="Hungary (English)" data-cmp-clickable>Hungary (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item23-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/in-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;India (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/in-en" role="menuitem" aria-label="India (English)" data-cmp-clickable>India (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item24-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/id-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Indonesia (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/id-en" role="menuitem" aria-label="Indonesia (English)" data-cmp-clickable>Indonesia (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item25-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/ie-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Ireland (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/ie-en" role="menuitem" aria-label="Ireland (English)" data-cmp-clickable>Ireland (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item26-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/il-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Israel (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/il-en" role="menuitem" aria-label="Israel (English)" data-cmp-clickable>Israel (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item27-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/it-it&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Italy (Italian)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/it-it" role="menuitem" aria-label="Italy (Italian)" data-cmp-clickable>Italy (Italian)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item28-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/jp-ja&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Japan (Japanese)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/jp-ja" role="menuitem" aria-label="Japan (Japanese)" data-cmp-clickable>Japan (Japanese)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item30-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/lv-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Latvia (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/lv-en" role="menuitem" aria-label="Latvia (English)" data-cmp-clickable>Latvia (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item32-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/lu-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Luxembourg (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/lu-en" role="menuitem" aria-label="Luxembourg (English)" data-cmp-clickable>Luxembourg (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item33-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/my-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Malaysia (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/my-en" role="menuitem" aria-label="Malaysia (English)" data-cmp-clickable>Malaysia (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item34-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/mu-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Mauritius (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/mu-en" role="menuitem" aria-label="Mauritius (English)" data-cmp-clickable>Mauritius (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item35-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/mx-es&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Mexico (Spanish)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/mx-es" role="menuitem" aria-label="Mexico (Spanish)" data-cmp-clickable>Mexico (Spanish)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item36-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/ma-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Morocco (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/ma-en" role="menuitem" aria-label="Morocco (English)" data-cmp-clickable>Morocco (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item38-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/nl-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Netherlands (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/nl-en" role="menuitem" aria-label="Netherlands (English)" data-cmp-clickable>Netherlands (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item39-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/nz-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;New Zealand (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/nz-en" role="menuitem" aria-label="New Zealand (English)" data-cmp-clickable>New Zealand (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item40-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/no-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Norway (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/no-en" role="menuitem" aria-label="Norway (English)" data-cmp-clickable>Norway (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item41-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/ph-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Philippines (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/ph-en" role="menuitem" aria-label="Philippines (English)" data-cmp-clickable>Philippines (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item42-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/pl-pl&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Poland (Polish)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/pl-pl" role="menuitem" aria-label="Poland (Polish)" data-cmp-clickable>Poland (Polish)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item44-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/pt-pt&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Portugal (Portuguese)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/pt-pt" role="menuitem" aria-label="Portugal (Portuguese)" data-cmp-clickable>Portugal (Portuguese)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item46-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/ro-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Romania (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/ro-en" role="menuitem" aria-label="Romania (English)" data-cmp-clickable>Romania (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item47-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/sa-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Saudi Arabia (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/sa-en" role="menuitem" aria-label="Saudi Arabia (English)" data-cmp-clickable>Saudi Arabia (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item49-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/sg-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Singapore (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/sg-en" role="menuitem" aria-label="Singapore (English)" data-cmp-clickable>Singapore (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item51-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/sk-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Slovakia (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/sk-en" role="menuitem" aria-label="Slovakia (English)" data-cmp-clickable>Slovakia (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item52-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/za-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;South Africa (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/za-en" role="menuitem" aria-label="South Africa (English)" data-cmp-clickable>South Africa (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item53-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/es-es&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Spain (Spanish)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/es-es" role="menuitem" aria-label="Spain (Spanish)" data-cmp-clickable>Spain (Spanish)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item55-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/se-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Sweden (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/se-en" role="menuitem" aria-label="Sweden (English)" data-cmp-clickable>Sweden (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item56-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/ch-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Switzerland (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/ch-en" role="menuitem" aria-label="Switzerland (English)" data-cmp-clickable>Switzerland (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item58-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/th-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;Thailand (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/th-en" role="menuitem" aria-label="Thailand (English)" data-cmp-clickable>Thailand (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item60-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/ae-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;UAE (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/ae-en" role="menuitem" aria-label="UAE (English)" data-cmp-clickable>UAE (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item61-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/gb-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;United Kingdom (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/gb-en" role="menuitem" aria-label="United Kingdom (English)" data-cmp-clickable>United Kingdom (English)</a>
                </li>
<li role="none" data-cmp-data-layer="{&#34;globalheader-sitelinks-item62-22ac66113c&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;language&#34;,&#34;analytics-link-name&#34;:&#34;USA (English)&#34;,&#34;analytics-module-name&#34;:&#34;top nav&#34;}}">
                  <a href="/us-en" role="menuitem" aria-label="USA (English)" data-cmp-clickable>USA (English)</a>
                </li>

              </ul>
            </div>
          </div>
        </div>

        </div>
      </div>
    </nav>
  <div class="cmp-global-header__menu-overlay"></div>
</div>




    
</div>

        
    </div>

</div>

    
</header>
<main class="container responsivegrid">

    
    
    
    <div id="main" class="cmp-container">
        
        <div class="fourcellblock"><div id="fourcellblock-606b559558" data-cmp-data-layer="{&#34;fourcellblock-606b559558&#34;:{&#34;@type&#34;:&#34;cio-sites/components/blocks/fourcellblock&#34;,&#34;analytics-module-name&#34;:&#34;fourcellblock-1&#34;,&#34;analytics-template-zone&#34;:&#34;block-pnf-content&#34;}}" class="cmp-fourcellblock" data-analytics-template-zone="block-pnf-content">

	<div class="cmp-four-cell">
		
		<div class="cmp-four-cell__first-row cmp-four-cell__fullwidth cmp-four-cell__first-row--cta-row">
			<div class="cmp-four-cell__first-col">
				<div class="container responsivegrid full-width-constraint">

    
    
    
    <div id="container-0f9bcc5e7c" class="cmp-container" style="background-color:rgb(242,242,242);">
        
        <div class="title ui-vs-top--lg ui-vs-bottom--lg">
<div data-cmp-data-layer="{&#34;title-f8ea0fae01&#34;:{&#34;@type&#34;:&#34;cio-sites/components/title&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-link-type&#34;:&#34;engagement&#34;,&#34;analytics-link-name&#34;:&#34;Page Not Found&#34;,&#34;analytics-module-name&#34;:&#34;title-1&#34;}}" id="title-f8ea0fae01" class="cmp-title">
    <h1 class="cmp-title__text">Page Not Found</h1>
</div>

    

</div>
<div class="container responsivegrid">

    
    
    
    <div id="container-a62a89785f" class="cmp-container">
        
        <div class="internalsearchhero">


    

</div>

        
    </div>

</div>

        
    </div>

</div>

			</div>
			
		</div>
		

		

		<div class="cmp-four-cell__second-row cmp-four-cell__fullwidth">
			<div class="cmp-four-cell__first-col">
				<div class="container responsivegrid">

    
    
    
    <div id="container-8e6600c579" class="cmp-container">
        
        <div class="cardlistingblock cmp-card-layout--3-cards ui-vs-top--md ui-vs-bottom--md"><!-- Card Listing Block -->

<div class="cmp-card-listing 
   cmp-card-listing--full-width cmp-card-listing--with-cta" id="cardlistingblock-06bfb3141d" data-cmp-data-layer="{&#34;cardlistingblock-06bfb3141d&#34;:{&#34;@type&#34;:&#34;cio-sites/components/blocks/cardlistingblock&#34;,&#34;analytics-module-name&#34;:&#34;cardlistingblock-1&#34;}}">
	<div class="cmp-card-listing_first-row">
		<div class="cmp-card-listing_first-row_left-col">
			<div class="container responsivegrid">

    
    
    
    <div id="container-bda8e40cef" class="cmp-container">
        
        <div class="text ui-vs-top--bs ui-vs-bottom--lg cmp-text--table-bordered">
<div data-cmp-data-layer="{&#34;text-5c443c0341&#34;:{&#34;@type&#34;:&#34;cio-sites/components/text&#34;,&#34;analytics-module-name&#34;:&#34;text-1&#34;}}" id="text-5c443c0341" class="cmp-text cmp-consent--verify">
    <p>The page you are trying to access has been moved or renamed. Please use the <a href="/us-en/search/results" class="cmp-text__link cmp-text__link--default" target="_self" rel="noopener noreferrer" data-cmp-clickable="" data-cmp-data-layer="{&quot;text-5c443c0341-link-1&quot;:{&quot;tooltip&quot;:null,&quot;analytics-link-name&quot;:&quot;search functionality&quot;,&quot;analytics-link-type&quot;:&quot;cta&quot;,&quot;xdm:linkURL&quot;:&quot;/us-en/search/results&quot;,&quot;analytics-engagement&quot;:&quot;true&quot;}}">search functionality</a> to find what you are looking for, select a page from the site navigation or follow one of the links below.</p>

</div>

    

</div>

        
    </div>

</div>

		</div>
		
	</div>
	<div class="cmp-card-listing_second-row">
		<div class="container responsivegrid">

    
    
    
    <div id="container-d0bb07cb68" class="cmp-container">
        
        <div class="teaser dcc dcc-imagefoldtag card has-ellipsis color-background-gray">
<div id="imagefoldtag-2faa635c61" class="cmp-teaser" data-cmp-data-layer="{&#34;imagefoldtag-2faa635c61&#34;:{&#34;@type&#34;:&#34;cio-sites/components/modules/m.001/imagefoldtag&#34;,&#34;xdm:linkURL&#34;:&#34;/us-en/careers&#34;,&#34;analytics-module-name&#34;:&#34;imagefoldtag-1&#34;}}" data-mark-type="cio-sites/components/modules/m.001/imagefoldtag" data-mark-nodepath="/content/acom/us-en/errors/404/jcr:content/root/container_main/fourcellblock/secondrow-container-one/cardlistingblock/secondrowcontainer/imagefoldtag" data-mark-instance="imagefoldtag">
	
    
    <div class="cmp-teaser__image">
<div data-cmp-is="image" data-cmp-lazy data-cmp-lazythreshold="0" data-cmp-src="https://dynamicmedia.accenture.com/is/image/accenture/Accenture-Banner-RSE-F-1920x1080?qlt=85&amp;wid=%7B.width%7D&amp;ts=1686266540908&amp;fit=constrain&amp;dpr=off" data-cmp-widths="320,480,600,800,1024,1200,1600" data-cmp-dmimage data-asset="/content/dam/accenture/final/markets/europe/imagery/Accenture-Banner-RSE-F-1920x1080.jpg" data-asset-id="94bedc72-fc19-447a-9cf4-c5ec26aaf130" id="teaser-2faa635c61-image" data-cmp-data-layer="{&#34;teaser-2faa635c61-image&#34;:{&#34;@type&#34;:&#34;cio-sites/components/image&#34;,&#34;xdm:linkURL&#34;:&#34;/us-en/careers&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-link-type&#34;:&#34;engagement&#34;,&#34;analytics-link-name&#34;:&#34;Accenture-Banner-RSE-F-1920x1080.jpg&#34;,&#34;analytics-module-name&#34;:&#34;image-1&#34;}}" class="cmp-image " itemscope itemtype="http://schema.org/ImageObject">
    <a class="cmp-image__link" href="/us-en/careers" target="_self" data-cmp-clickable data-cmp-hook-image="link">
        <noscript data-cmp-hook-image="noscript">
            
            <img src="https://dynamicmedia.accenture.com/is/image/accenture/Accenture-Banner-RSE-F-1920x1080?qlt=85&ts=1686266540908&fit=constrain&dpr=off" class="cmp-image__image" itemprop="contentUrl" data-cmp-hook-image="image" alt/>
            
        </noscript>
    </a>
    
    

</div>

    
</div>

	
    <div class="cmp-teaser__content">
        
    <div class="cmp-teaser__pretitle">
		
		<a class="cmp-teaser__pretitle-link" data-cmp-clickable href="/us-en/careers" target="_self" data-cmp-data-layer="{&#34;imagefoldtag-2faa635c61-pretitle&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/careers&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-link-type&#34;:&#34;engagement&#34;,&#34;analytics-link-name&#34;:&#34;Accenture Careers&#34;}}" aria-label="Accenture Careers">
			Accenture Careers
		</a>
		</div>
	
 	

        
    <h3 class="cmp-teaser__title" data-mark="jcr:title">
		
        <a class="cmp-teaser__title-link" href="/us-en/careers" target="_self" aria-label="Accenture careers" data-cmp-data-layer="{&#34;imagefoldtag-2faa635c61-title&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/careers&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-link-type&#34;:&#34;engagement&#34;,&#34;analytics-link-name&#34;:&#34;Accenture careers&#34;}}" data-cmp-clickable>Accenture careers</a>
    </h3>

        
	<div class="cmp-teaser__description" data-mark="jcr:description"><p>At the heart of every great change is a great human. Every day our People of Change are doing incredible things by...</p>
</div>

        
    <div class="cmp-teaser__action-container">
        
    <a class="cmp-teaser__action-link" target="_self" aria-label="Read more: Discover your new career" data-cmp-data-layer="{&#34;imagefoldtag-item0-29b8c9637f&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/careers&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-link-type&#34;:&#34;engagement&#34;,&#34;analytics-link-name&#34;:&#34;Read more&#34;}}" data-cmp-clickable href="/us-en/careers">Read more</a>

    </div>

    </div>
</div>

    
</div>
<div class="teaser dcc dcc-imagefoldtag card has-ellipsis color-background-gray">
<div id="imagefoldtag-bbfbfcda1e" class="cmp-teaser" data-cmp-data-layer="{&#34;imagefoldtag-bbfbfcda1e&#34;:{&#34;@type&#34;:&#34;cio-sites/components/modules/m.001/imagefoldtag&#34;,&#34;xdm:linkURL&#34;:&#34;/us-en/insights/voices&#34;,&#34;analytics-module-name&#34;:&#34;imagefoldtag-2&#34;}}" data-mark-type="cio-sites/components/modules/m.001/imagefoldtag" data-mark-nodepath="/content/acom/us-en/errors/404/jcr:content/root/container_main/fourcellblock/secondrow-container-one/cardlistingblock/secondrowcontainer/imagefoldtag_186236642" data-mark-instance="imagefoldtag_186236642">
	
    
    <div class="cmp-teaser__image">
<div data-cmp-is="image" data-cmp-lazy data-cmp-lazythreshold="0" data-cmp-src="https://dynamicmedia.accenture.com/is/image/accenture/Top500-parallax-2?qlt=85&amp;wid=%7B.width%7D&amp;ts=1686266559547&amp;fit=constrain&amp;dpr=off" data-cmp-widths="320,480,600,800,1024,1200,1600" data-cmp-dmimage data-asset="/content/dam/accenture/final/markets/europe/imagery/Top500-parallax-2.jpg" data-asset-id="5b73c1b6-3cb3-405e-904c-49ebddbec343" id="teaser-bbfbfcda1e-image" data-cmp-data-layer="{&#34;teaser-bbfbfcda1e-image&#34;:{&#34;@type&#34;:&#34;cio-sites/components/image&#34;,&#34;xdm:linkURL&#34;:&#34;/us-en/insights/voices&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-link-type&#34;:&#34;engagement&#34;,&#34;analytics-link-name&#34;:&#34;Top500-parallax-2.jpg&#34;,&#34;analytics-module-name&#34;:&#34;image-2&#34;}}" class="cmp-image " itemscope itemtype="http://schema.org/ImageObject">
    <a class="cmp-image__link" href="/us-en/insights/voices" target="_self" data-cmp-clickable data-cmp-hook-image="link">
        <noscript data-cmp-hook-image="noscript">
            
            <img src="https://dynamicmedia.accenture.com/is/image/accenture/Top500-parallax-2?qlt=85&ts=1686266559547&fit=constrain&dpr=off" class="cmp-image__image" itemprop="contentUrl" data-cmp-hook-image="image" alt/>
            
        </noscript>
    </a>
    
    

</div>

    
</div>

	
    <div class="cmp-teaser__content">
        
    <div class="cmp-teaser__pretitle">
		
		<a class="cmp-teaser__pretitle-link" data-cmp-clickable href="/us-en/insights/voices" target="_self" data-cmp-data-layer="{&#34;imagefoldtag-bbfbfcda1e-pretitle&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/insights/voices&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-link-type&#34;:&#34;engagement&#34;,&#34;analytics-link-name&#34;:&#34;Featured content&#34;}}" aria-label="Featured content">
			Featured content
		</a>
		</div>
	
 	

        
    <h3 class="cmp-teaser__title" data-mark="jcr:title">
		
        <a class="cmp-teaser__title-link" href="/us-en/insights/voices" target="_self" aria-label="Voices of Change" data-cmp-data-layer="{&#34;imagefoldtag-bbfbfcda1e-title&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/insights/voices&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-link-type&#34;:&#34;engagement&#34;,&#34;analytics-link-name&#34;:&#34;Voices of Change&#34;}}" data-cmp-clickable>Voices of Change</a>
    </h3>

        
	<div class="cmp-teaser__description" data-mark="jcr:description"><p>The path to 360° value starts here—featuring out most provokative thinking, extensive research ang compelling...</p>
</div>

        
    <div class="cmp-teaser__action-container">
        
    <a class="cmp-teaser__action-link" target="_self" aria-label="Read more: Voices of Change" data-cmp-data-layer="{&#34;imagefoldtag_186236642-item0-f8dbeea42f&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/insights/voices&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-link-type&#34;:&#34;engagement&#34;,&#34;analytics-link-name&#34;:&#34;Read more&#34;}}" data-cmp-clickable href="/us-en/insights/voices">Read more</a>

    </div>

    </div>
</div>

    
</div>
<div class="teaser dcc dcc-imagefoldtag card has-ellipsis color-background-gray">
<div id="imagefoldtag-c72ddccbd9" class="cmp-teaser" data-cmp-data-layer="{&#34;imagefoldtag-c72ddccbd9&#34;:{&#34;@type&#34;:&#34;cio-sites/components/modules/m.001/imagefoldtag&#34;,&#34;xdm:linkURL&#34;:&#34;/us-en/about/company/integrated-reporting&#34;,&#34;analytics-module-name&#34;:&#34;imagefoldtag-3&#34;}}" data-mark-type="cio-sites/components/modules/m.001/imagefoldtag" data-mark-nodepath="/content/acom/us-en/errors/404/jcr:content/root/container_main/fourcellblock/secondrow-container-one/cardlistingblock/secondrowcontainer/imagefoldtag_376414283" data-mark-instance="imagefoldtag_376414283">
	
    
    <div class="cmp-teaser__image">
<div data-cmp-is="image" data-cmp-lazy data-cmp-lazythreshold="0" data-cmp-src="https://dynamicmedia.accenture.com/is/image/accenture/Lights-Passing-Through-Buildings-In-A-City-1200x400?qlt=85&amp;wid=%7B.width%7D&amp;ts=1686266556073&amp;fit=constrain&amp;dpr=off" data-cmp-widths="320,480,600,800,1024,1200,1600" data-cmp-dmimage data-asset="/content/dam/accenture/final/markets/europe/imagery/Lights-Passing-Through-Buildings-In-A-City-1200x400.jpeg" data-asset-id="25c8e0cb-58d6-43fb-8dfc-6e2ec009780f" id="teaser-c72ddccbd9-image" data-cmp-data-layer="{&#34;teaser-c72ddccbd9-image&#34;:{&#34;@type&#34;:&#34;cio-sites/components/image&#34;,&#34;xdm:linkURL&#34;:&#34;/us-en/about/company/integrated-reporting&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-link-type&#34;:&#34;engagement&#34;,&#34;analytics-link-name&#34;:&#34;Lights-Passing-Through-Buildings-In-A-City-1200x400.jpeg&#34;,&#34;analytics-module-name&#34;:&#34;image-3&#34;}}" class="cmp-image " itemscope itemtype="http://schema.org/ImageObject">
    <a class="cmp-image__link" href="/us-en/about/company/integrated-reporting" target="_self" data-cmp-clickable data-cmp-hook-image="link">
        <noscript data-cmp-hook-image="noscript">
            
            <img src="https://dynamicmedia.accenture.com/is/image/accenture/Lights-Passing-Through-Buildings-In-A-City-1200x400?qlt=85&ts=1686266556073&fit=constrain&dpr=off" class="cmp-image__image" itemprop="contentUrl" data-cmp-hook-image="image" alt/>
            
        </noscript>
    </a>
    
    

</div>

    
</div>

	
    <div class="cmp-teaser__content">
        
    <div class="cmp-teaser__pretitle">
		
		<a class="cmp-teaser__pretitle-link" data-cmp-clickable href="/us-en/about/company/integrated-reporting" target="_self" data-cmp-data-layer="{&#34;imagefoldtag-c72ddccbd9-pretitle&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/about/company/integrated-reporting&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-link-type&#34;:&#34;engagement&#34;,&#34;analytics-link-name&#34;:&#34;Integrated reporting&#34;}}" aria-label="Integrated reporting">
			Integrated reporting
		</a>
		</div>
	
 	

        
    <h3 class="cmp-teaser__title" data-mark="jcr:title">
		
        <a class="cmp-teaser__title-link" href="/us-en/about/company/integrated-reporting" target="_self" aria-label="360° Value" data-cmp-data-layer="{&#34;imagefoldtag-c72ddccbd9-title&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/about/company/integrated-reporting&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-link-type&#34;:&#34;engagement&#34;,&#34;analytics-link-name&#34;:&#34;360° Value&#34;}}" data-cmp-clickable>360° Value</a>
    </h3>

        
	<div class="cmp-teaser__description" data-mark="jcr:description"><p>Every day, in all directions, we measure our success by the value we deliver for all stakeholders.</p>
</div>

        
    <div class="cmp-teaser__action-container">
        
    <a class="cmp-teaser__action-link" target="_self" aria-label="Read more: Explore 360° value" data-cmp-data-layer="{&#34;imagefoldtag_376414283-item0-127e12869e&#34;:{&#34;xdm:linkURL&#34;:&#34;/content/acom/us-en/about/company/integrated-reporting&#34;,&#34;analytics-engagement&#34;:&#34;true&#34;,&#34;analytics-link-type&#34;:&#34;engagement&#34;,&#34;analytics-link-name&#34;:&#34;Read more&#34;}}" data-cmp-clickable href="/us-en/about/company/integrated-reporting">Read more</a>

    </div>

    </div>
</div>

    
</div>

        
    </div>

</div>

		<div class="button cmp-card-listing_button cmp-button--text-link cmp-button__cta-arrow--right">
			
		</div>
	</div>

	
	<div class="cmp-card-listing_third-row ">
		<div class="container responsivegrid">

    
    
    
    <div id="container-a97d17ec79" class="cmp-container">
        
        <div class="text ui-vs-top--md ui-vs-bottom--lg cmp-text--table-bordered">
<div data-cmp-data-layer="{&#34;text-6ea3c3567b&#34;:{&#34;@type&#34;:&#34;cio-sites/components/text&#34;,&#34;analytics-module-name&#34;:&#34;text-2&#34;}}" id="text-6ea3c3567b" class="cmp-text cmp-consent--verify">
    <p><a href="https://www.accenture.com/us-en/about/consulting-index" class="cmp-text__link cmp-text__link--default" target="_blank" rel="noopener noreferrer" data-cmp-clickable="" data-cmp-data-layer="{&quot;text-6ea3c3567b-link-1&quot;:{&quot;tooltip&quot;:null,&quot;analytics-link-name&quot;:&quot;strategy &amp; consulting&quot;,&quot;analytics-link-type&quot;:&quot;cta&quot;,&quot;xdm:linkURL&quot;:&quot;https://www.accenture.com/us-en/about/consulting-index&quot;,&quot;analytics-engagement&quot;:&quot;true&quot;}}">Strategy &amp; Consulting</a> | <a href="https://www.accenture.com/us-en/about/accenture-song-index" class="cmp-text__link cmp-text__link--default" target="_self" rel="noopener noreferrer" data-cmp-clickable="" data-cmp-data-layer="{&quot;text-6ea3c3567b-link-2&quot;:{&quot;tooltip&quot;:null,&quot;analytics-link-name&quot;:&quot;song&quot;,&quot;analytics-link-type&quot;:&quot;cta&quot;,&quot;xdm:linkURL&quot;:&quot;https://www.accenture.com/us-en/about/accenture-song-index&quot;,&quot;analytics-engagement&quot;:&quot;true&quot;}}">Song</a> | <a href="https://www.accenture.com/us-en/about/technology-index" class="cmp-text__link cmp-text__link--default" target="_self" rel="noopener noreferrer" data-cmp-clickable="" data-cmp-data-layer="{&quot;text-6ea3c3567b-link-3&quot;:{&quot;tooltip&quot;:null,&quot;analytics-link-name&quot;:&quot;technology&quot;,&quot;analytics-link-type&quot;:&quot;cta&quot;,&quot;xdm:linkURL&quot;:&quot;https://www.accenture.com/us-en/about/technology-index&quot;,&quot;analytics-engagement&quot;:&quot;true&quot;}}">Technology</a> | <a href="https://www.accenture.com/us-en/about/operations-index" class="cmp-text__link cmp-text__link--default" target="_blank" rel="noopener noreferrer" data-cmp-clickable="" data-cmp-data-layer="{&quot;text-6ea3c3567b-link-4&quot;:{&quot;tooltip&quot;:null,&quot;analytics-link-name&quot;:&quot;operations&quot;,&quot;analytics-link-type&quot;:&quot;cta&quot;,&quot;xdm:linkURL&quot;:&quot;https://www.accenture.com/us-en/about/operations-index&quot;,&quot;analytics-engagement&quot;:&quot;true&quot;}}">Operations</a> | <a href="https://www.accenture.com/us-en/about/industry-x-index" class="cmp-text__link cmp-text__link--default" target="_self" rel="noopener noreferrer" data-cmp-clickable="" data-cmp-data-layer="{&quot;text-6ea3c3567b-link-5&quot;:{&quot;tooltip&quot;:null,&quot;analytics-link-name&quot;:&quot;industry x&quot;,&quot;analytics-link-type&quot;:&quot;cta&quot;,&quot;xdm:linkURL&quot;:&quot;https://www.accenture.com/us-en/about/industry-x-index&quot;,&quot;analytics-engagement&quot;:&quot;true&quot;}}">Industry X</a> |  <a href="https://www.accenture.com/us-en/careers" class="cmp-text__link cmp-text__link--default" target="_self" rel="noopener noreferrer" data-cmp-clickable="" data-cmp-data-layer="{&quot;text-6ea3c3567b-link-6&quot;:{&quot;tooltip&quot;:null,&quot;analytics-link-name&quot;:&quot;careers&quot;,&quot;analytics-link-type&quot;:&quot;cta&quot;,&quot;xdm:linkURL&quot;:&quot;https://www.accenture.com/us-en/careers&quot;,&quot;analytics-engagement&quot;:&quot;true&quot;}}">Careers</a><br />
</p>

</div>

    

</div>

        
    </div>

</div>


	</div>
</div></div>

        
    </div>

</div>

			</div>
			
		</div>

		

		<div class="cmp-four-cell__third-row cmp-four-cell__fullwidth ">
			<div class="cmp-four-cell__first-col">
				<div class="container responsivegrid">

    
    
    
    <div id="container-db5d047928" class="cmp-container">
        
        
        
    </div>

</div>

			</div>
		</div>
	</div>
</div>


</div>

        
    </div>

</main>
<footer class="customexperiencefragment experiencefragment full-width">
<div id="footer" class="cmp-experiencefragment cmp-experiencefragment--global-footer">


    
    <div id="container-8e84eced14" class="cmp-container" style="background-color:rgb(0,0,0);">
        


<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
    
    <div class="block-content-configuration teaser aem-GridColumn aem-GridColumn--default--12"><div style="display:none">
     

        <ul class="blockContent-config">
            <li class="content customHTMLConfig" srclink="https://www.knotch-cdn.com/unit/latest/knotch.min.js" categoryCH="0"></li>
        
            <li class="content customHTMLConfig" srclink="https://www.youtube-nocookie.com" categoryCH="4"></li>
        </ul>

        <div class="cmp-embed-config" isboxdialogenabled="true" isblockyt="true" consentcat="4">
         <div class="cmp-yt-verbiage">
			<p>Please enable Advertising and Social Media Cookies to be able to see this content.<br />
Click <a href="#" class="cmp-text__link cmp-text__link--default" data-cmp-clickable="" data-cmp-data-layer="{&quot;text-6ea3c3567b-link-7&quot;:{&quot;tooltip&quot;:null,&quot;analytics-link-name&quot;:&quot;here&quot;,&quot;analytics-link-type&quot;:&quot;cta&quot;,&quot;xdm:linkURL&quot;:&quot;#&quot;,&quot;analytics-engagement&quot;:&quot;true&quot;}}">here</a> to update your cookie settings.</p>

            </div>
        </div>
    
</div>




    
</div>
<div class="globalfooter has-tooltip aem-GridColumn aem-GridColumn--default--12">

<div class="cmp-global-footer" id="globalfooter-7c8989b6d6" data-cmp-data-layer="{&#34;globalfooter-7c8989b6d6&#34;:{&#34;@type&#34;:&#34;cio-sites/components/blocks/b.002/globalfooter&#34;,&#34;analytics-module-name&#34;:&#34;footer&#34;,&#34;analytics-template-zone&#34;:&#34;footer&#34;}}">
		<div class="cmp-global-footer__row">
			<div class="cmp-global-footer__logo">
				<a href="https://www.accenture.com/us-en" data-cmp-data-layer="{&#34;globalfooter-logo-2c652f6737&#34;:{&#34;xdm:linkURL&#34;:&#34;https://www.accenture.com/us-en&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;footer&#34;,&#34;analytics-link-name&#34;:&#34;accenture logo - footer&#34;}}" data-cmp-clickable>
					<img class="cmp-global-footer__logo-image" alt="Accenture Home" src="/content/dam/accenture/final/images/icons/symbol/Acc_GT_Dimensional_RGB.svg" aria-label="Accenture Home"/>
	      		</a>
			</div>
			
			<div class="cmp-global-footer__links">
				<div class="cmp-global-footer__link-item cmp-global-footer__item--footer">
	        		<a href="/us-en/about/company-index" aria-label="About Us" target="_self" class="cmp-global-footer__link" data-cmp-data-layer="{&#34;globalfooter-footerlinks-item0-a934cec261&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/about/company-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;footer&#34;,&#34;analytics-link-name&#34;:&#34;About Us&#34;}}" data-cmp-clickable>
	        			About Us
	        		</a>
	      		</div>
			
				<div class="cmp-global-footer__link-item cmp-global-footer__item--footer">
	        		<a href="/us-en/about/contact-us" aria-label="Contact Us" target="_self" class="cmp-global-footer__link" data-cmp-data-layer="{&#34;globalfooter-footerlinks-item1-427752b247&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/about/contact-us&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;footer&#34;,&#34;analytics-link-name&#34;:&#34;Contact Us&#34;}}" data-cmp-clickable>
	        			Contact Us
	        		</a>
	      		</div>
			
				<div class="cmp-global-footer__link-item cmp-global-footer__item--footer">
	        		<a href="/us-en/careers" aria-label="Careers" target="_self" class="cmp-global-footer__link" data-cmp-data-layer="{&#34;globalfooter-footerlinks-item2-c1fd9499e4&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/careers&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;footer&#34;,&#34;analytics-link-name&#34;:&#34;Careers&#34;}}" data-cmp-clickable>
	        			Careers
	        		</a>
	      		</div>
			
				<div class="cmp-global-footer__link-item cmp-global-footer__item--footer">
	        		<a href="/us-en/about/location-index" aria-label="Locations" target="_self" class="cmp-global-footer__link" data-cmp-data-layer="{&#34;globalfooter-footerlinks-item3-3e2b8f09f5&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/about/location-index&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;footer&#34;,&#34;analytics-link-name&#34;:&#34;Locations&#34;}}" data-cmp-clickable>
	        			Locations
	        		</a>
	      		</div>
			</div>
			<div class="cmp-global-footer__share">
				
    

<div id="sharebanner-3c99330609" class="cmp-share-banner " data-cmp-data-layer="{&#34;sharebanner-3c99330609&#34;:{&#34;@type&#34;:&#34;cio-sites/components/modules/m.014/sharebanner&#34;,&#34;analytics-module-name&#34;:&#34;sharebanner-1&#34;,&#34;analytics-template-zone&#34;:&#34;footer&#34;}}">
   <div class="h-title-eyebrow"></div>
   	<div class="cmp-share-banner__items">
      
         <div class="cmp-share-banner__item ">
            <a data-cmp-clickable data-cmp-data-layer="{&#34;sharebanner-item0-4554817acf&#34;:{&#34;@type&#34;:&#34;nt:unstructured&#34;,&#34;xdm:linkURL&#34;:&#34;https://www.linkedin.com/company/accenture&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;footer&#34;,&#34;analytics-link-name&#34;:&#34;linkedin&#34;,&#34;tooltip&#34;:&#34;Connect with us on LinkedIn&#34;}}" class="cmp-share-banner__icon cmp-share-banner__icon--linkedin" href="https://www.linkedin.com/company/accenture" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn" data-tooltip="Connect with us on LinkedIn"></a>
           	
         </div>
      
         <div class="cmp-share-banner__item ">
            <a data-cmp-clickable data-cmp-data-layer="{&#34;sharebanner-item1-897342e8d5&#34;:{&#34;@type&#34;:&#34;nt:unstructured&#34;,&#34;xdm:linkURL&#34;:&#34;https://twitter.com/Accenture_US&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;footer&#34;,&#34;analytics-link-name&#34;:&#34;twitter&#34;,&#34;tooltip&#34;:&#34;Follow us on Twitter&#34;}}" class="cmp-share-banner__icon cmp-share-banner__icon--twitter" href="https://twitter.com/Accenture_US" target="_blank" rel="noopener noreferrer" aria-label="Twitter" data-tooltip="Follow us on Twitter"></a>
           	
         </div>
      
         <div class="cmp-share-banner__item ">
            <a data-cmp-clickable data-cmp-data-layer="{&#34;sharebanner-item2-dd2a2293b4&#34;:{&#34;@type&#34;:&#34;nt:unstructured&#34;,&#34;xdm:linkURL&#34;:&#34;https://www.facebook.com/AccentureUS&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;footer&#34;,&#34;analytics-link-name&#34;:&#34;facebook&#34;,&#34;tooltip&#34;:&#34;Like us on Facebook&#34;}}" class="cmp-share-banner__icon cmp-share-banner__icon--facebook" href="https://www.facebook.com/AccentureUS" target="_blank" rel="noopener noreferrer" aria-label="Facebook" data-tooltip="Like us on Facebook"></a>
           	
         </div>
      
         <div class="cmp-share-banner__item ">
            <a data-cmp-clickable data-cmp-data-layer="{&#34;sharebanner-item3-b1cb9c736e&#34;:{&#34;@type&#34;:&#34;nt:unstructured&#34;,&#34;xdm:linkURL&#34;:&#34;https://www.instagram.com/accentureus/&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;footer&#34;,&#34;analytics-link-name&#34;:&#34;instagram&#34;,&#34;tooltip&#34;:&#34;Follow us on Instagram&#34;}}" class="cmp-share-banner__icon cmp-share-banner__icon--instagram" href="https://www.instagram.com/accentureus/" target="_blank" rel="noopener noreferrer" aria-label="Instagram" data-tooltip="Follow us on Instagram"></a>
           	
         </div>
      
         <div class="cmp-share-banner__item ">
            <a data-cmp-clickable data-cmp-data-layer="{&#34;sharebanner-item4-e9a86a2f2a&#34;:{&#34;@type&#34;:&#34;nt:unstructured&#34;,&#34;xdm:linkURL&#34;:&#34;https://www.youtube.com/accenture&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;footer&#34;,&#34;analytics-link-name&#34;:&#34;youtube&#34;,&#34;tooltip&#34;:&#34;See Accenture on Youtube&#34;}}" class="cmp-share-banner__icon cmp-share-banner__icon--youtube" href="https://www.youtube.com/accenture" target="_blank" rel="noopener noreferrer" aria-label="Youtube" data-tooltip="See Accenture on Youtube"></a>
           	
         </div>
      
   </div>
   <!-- begining Button Toolbar -->
   
   <!-- End Button Toolbar -->
</div>
	     	</div>
	    </div>
		<div class="cmp-global-footer__legal-row">
			<div class="cmp-global-footer__legal-wrap">
				<div class="cmp-global-footer__link-item cmp-global-footer__link-item--legal">
	        		<a href="/us-en/about/privacy-policy" aria-label="Privacy Statement" target="_self" class="cmp-global-footer__legal-link" data-cmp-data-layer="{&#34;globalfooter-legallinks-item0-5723f0446f&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/about/privacy-policy&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;footer&#34;,&#34;analytics-link-name&#34;:&#34;Privacy Statement&#34;}}" data-cmp-clickable>
	        			Privacy Statement
	        		</a>
	      		</div>
				
    		
				<div class="cmp-global-footer__link-item cmp-global-footer__link-item--legal">
	        		<a href="/us-en/support/terms-of-use" aria-label="Terms &amp; Conditions" target="_self" class="cmp-global-footer__legal-link" data-cmp-data-layer="{&#34;globalfooter-legallinks-item1-ec6aec9eb5&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/support/terms-of-use&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;footer&#34;,&#34;analytics-link-name&#34;:&#34;Terms &amp; Conditions&#34;}}" data-cmp-clickable>
	        			Terms &amp; Conditions
	        		</a>
	      		</div>
				
    		
				<div class="cmp-global-footer__link-item cmp-global-footer__link-item--legal">
	        		<a href="/us-en/support/company-cookies-similar-technology" aria-label="Cookie Policy/Settings" target="_self" class="cmp-global-footer__legal-link" data-cmp-data-layer="{&#34;globalfooter-legallinks-item2-9308ec5769&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/support/company-cookies-similar-technology&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;footer&#34;,&#34;analytics-link-name&#34;:&#34;Cookie Policy/Settings&#34;}}" data-cmp-clickable>
	        			Cookie Policy/Settings
	        		</a>
	      		</div>
				
    		
				<div class="cmp-global-footer__link-item cmp-global-footer__link-item--legal">
	        		<a href="/us-en/support/accessibility-statement" aria-label="Accessibility Statement" target="_self" class="cmp-global-footer__legal-link" data-cmp-data-layer="{&#34;globalfooter-legallinks-item3-e34d7b508f&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/support/accessibility-statement&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;footer&#34;,&#34;analytics-link-name&#34;:&#34;Accessibility Statement&#34;}}" data-cmp-clickable>
	        			Accessibility Statement
	        		</a>
	      		</div>
				
    		
				<div class="cmp-global-footer__link-item cmp-global-footer__link-item--legal">
	        		<a href="/us-en/about/site-map" aria-label="Sitemap" target="_self" class="cmp-global-footer__legal-link" data-cmp-data-layer="{&#34;globalfooter-legallinks-item4-d69aafa605&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/about/site-map&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;footer&#34;,&#34;analytics-link-name&#34;:&#34;Sitemap&#34;}}" data-cmp-clickable>
	        			Sitemap
	        		</a>
	      		</div>
				
    		
				<div class="cmp-global-footer__link-item cmp-global-footer__link-item--legal">
	        		<a href="/us-en/form-do-not-sell-my-personal-information" aria-label="Do Not Sell/Share My Personal Information (for CA)" target="_self" class="cmp-global-footer__legal-link" data-cmp-data-layer="{&#34;globalfooter-legallinks-item5-7dd6a2f3b8&#34;:{&#34;xdm:linkURL&#34;:&#34;/us-en/form-do-not-sell-my-personal-information&#34;,&#34;analytics-engagement&#34;:&#34;false&#34;,&#34;analytics-link-type&#34;:&#34;footer&#34;,&#34;analytics-link-name&#34;:&#34;Do Not Sell/Share My Personal Information (for CA)&#34;}}" data-cmp-clickable>
	        			Do Not Sell/Share My Personal Information (for CA)
	        		</a>
	      		</div>
				<div class="cmp-global-footer__copy-right">
				    <p class="cmp-global-footer__copy-right-text">
				    &#169; 2023 Accenture. All Rights Reserved.
				    </p>
	    		</div>
    		</div>
		</div>
	</div>



    
</div>

    
</div>

    </div>

    
</div>

    
</footer>

        
    </div>

</div>


  

  

   
  
            
    
    
    
    


    <!-- customfooter -->
    
        <script defer src="/etc.clientlibs/cio-sites/clientlibs/clientlib-site.lc-aef1996c265af034516b793ad07ee884-lc.min.js"></script>

    
    
        <script defer src="/etc.clientlibs/core/wcm/components/commons/site/clientlibs/container.lc-0a6aff292f5cc42142779cde92054524-lc.min.js"></script>
<script defer src="/etc.clientlibs/cio-sites/clientlibs/clientlib-base.lc-012ae2b1d05e8ff137d70f70afce04c9-lc.min.js"></script>

    

    
    
    

    







<script>
    window.addEventListener('DOMContentLoaded',()=>{
        const form = document.querySelectorAll("form");
        if (form.length > 0) {
            var rcScript = document.createElement("script");
            rcScript.setAttribute("type","text/javascript");
            rcScript.setAttribute("data-document-language","true");
            rcScript.setAttribute("charset","UTF-8");
            rcScript.setAttribute("src","https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit");
            document.body.appendChild(rcScript);
        }
    })
</script>


    

    

    



    



    
    



    

    

        
    </body>
</html>
